# 完整示例: 用户认证模块

## 任务输入
```
/orchestrate 实现用户认证模块，包含注册、登录、密码重置功能
```

---

## Phase 1: 框架生成

Orchestrator 生成 `task-framework.md`:

```markdown
# 任务框架: 用户认证模块

## 任务概述
实现完整的用户认证系统，支持注册、登录、密码重置功能。

## 子任务分解

### SUB-001: 数据模型设计
- **目标**: 设计用户数据模型和数据库 schema
- **依赖**: 无
- **建议Agent**: Worker-1
- **建议Skills**: 无
- **建议Tools**: Write, Read
- **验收标准**:
  - [ ] 用户表 schema 定义完整
  - [ ] 包含必要字段: id, email, password_hash, created_at
  - [ ] 索引设计合理

### SUB-002: 注册功能实现
- **目标**: 实现用户注册 API
- **依赖**: SUB-001
- **建议Agent**: Worker-2
- **建议Skills**: claude-api
- **建议Tools**: Write, Edit, Bash
- **验收标准**:
  - [ ] POST /api/register 返回正确状态码
  - [ ] 密码加密存储
  - [ ] 邮箱唯一性校验

### SUB-003: 登录功能实现
- **目标**: 实现用户登录 API
- **依赖**: SUB-001
- **建议Agent**: Worker-3
- **建议Skills**: claude-api
- **建议Tools**: Write, Edit, Bash
- **验收标准**:
  - [ ] POST /api/login 返回 JWT token
  - [ ] 错误场景处理完善
  - [ ] 登录日志记录

### SUB-004: 密码重置功能实现
- **目标**: 实现密码重置流程
- **依赖**: SUB-001
- **建议Agent**: Worker-4
- **建议Skills**: claude-api
- **建议Tools**: Write, Edit, Bash
- **验收标准**:
  - [ ] 发送重置邮件
  - [ ] token 有效期 1 小时
  - [ ] 重置成功后通知用户
```

---

## Phase 2: 任务分发

Orchestrator 并行启动 4 个 Worker:

```javascript
// Worker-1
Agent({
  subagent_type: "general-purpose",
  isolation: "worktree",
  prompt: `
    [WORKER PROMPT]
    
    任务ID: SUB-001
    目标: 设计用户数据模型
    验收标准: ...
    可用工具: Write, Read
  `
})

// Worker-2, Worker-3, Worker-4 类似...
```

---

## Phase 3: Worker 执行与报告

### Worker-1 报告摘要

```markdown
# 任务报告: SUB-001

## 执行摘要
设计了 users 表和 password_reset_tokens 表。

## 验证结果
- [x] 用户表 schema 定义完整
- [x] 包含必要字段
- [x] 索引设计合理 (email 唯一索引)

## 审查发现
- 代码质量: 9/10 - 结构清晰
- 安全性: 10/10 - 密码字段使用 bcrypt
- 性能: 8/10 - 索引合理

## 文件变更
| 文件 | 操作 | 说明 |
|------|------|------|
| db/schema/users.sql | 创建 | 用户表定义 |
| db/schema/reset_tokens.sql | 创建 | 重置 token 表 |
```

### Worker-2 报告摘要

```markdown
# 任务报告: SUB-002

## 执行摘要
实现了注册 API，包含邮箱校验和密码加密。

## 验证结果
- [x] POST /api/register 返回 201
- [x] 密码使用 bcrypt 加密
- [x] 重复邮箱返回 409

## 审查发现
- 代码质量: 8/10 - 有 TODO 待处理
- 安全性: 9/10 - 输入校验完善
- 性能: 7/10 - 可添加邮箱索引检查

## 遗留问题
| 问题 | 优先级 | 建议 |
|------|--------|------|
| 添加 rate limiting | P2 | 后续迭代 |
```

---

## Phase 4: 审查验证

Reviewer 生成 `review-report.md`:

```markdown
# 审查报告

## 总体评估
- 完成率: 4/4 (100%)
- 平均质量分: 8.5/10
- 验证状态: PASS

## 发现的问题
1. Worker-2 报告中 TODO 未处理 - P3 - 建议创建后续任务
2. 所有 Worker 需要添加单元测试 - P2 - 补充测试用例

## 通过的任务
- SUB-001: 数据模型设计合理
- SUB-002: 注册功能完整
- SUB-003: 登录逻辑正确
- SUB-004: 重置流程完善
```

---

## Phase 5: 归档

Archiver 生成 `PROJECT-SPEC.md`:

```markdown
# 项目技术规范: 用户认证模块

## 项目概述
- 路径: /projects/auth-module
- 技术栈: Node.js, Express, PostgreSQL, bcrypt, JWT

## 功能模块
| 模块 | 职责 | 文件 |
|------|------|------|
| 数据层 | 用户数据存储 | db/schema/*.sql |
| API层 | 认证接口 | src/routes/auth.ts |
| 服务层 | 业务逻辑 | src/services/auth.ts |

## Agent 责任矩阵
| Agent | 本次任务 | 最佳实践 |
|-------|----------|----------|
| Worker-DB | Schema 设计 | 先设计后实现 |
| Worker-API | 接口开发 | 先写测试 |

## 工作流约束
1. 所有 API 必须有错误处理
2. 密码相关使用 bcrypt
3. Token 有效期不超过 24h
```

---

## 最终输出

```
✅ 任务完成

📁 生成文件:
- .claude/workspace/task-framework.md
- .claude/workspace/task-report-001.md
- .claude/workspace/task-report-002.md
- .claude/workspace/task-report-003.md
- .claude/workspace/task-report-004.md
- .claude/workspace/review-report.md
- .claude/rules/project-spec.md

📊 统计:
- 总耗时: 12 分钟
- Agent 调用: 6 次
- 文件变更: 8 个
- 质量评分: 8.5/10
```
