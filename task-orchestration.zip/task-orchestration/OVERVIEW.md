# Task Orchestration Workflow Script

本目录包含完整的多 Agent 任务编排系统。

## 文件结构

```
task-orchestration/
├── README.md              # 使用说明
├── skill.md               # Skill 定义
├── prompts/
│   ├── orchestrator.md    # 主控 Agent 提示词
│   ├── worker.md          # 执行 Agent 提示词
│   ├── reviewer.md        # 审查 Agent 提示词
│   └── archiver.md        # 归档 Agent 提示词
├── templates/
│   ├── task-framework.md  # 任务框架模板
│   ├── task-report.md     # 任务报告模板
│   └── project-spec.md    # 项目规范模板
└── examples/
    └── auth-module.md     # 完整示例
```

## 使用方式

### 方式 1: 手动调用
```
/orchestrate 实现用户认证模块
```

### 方式 2: 在项目中配置
在项目 `.claude/rules/` 中创建 `use-orchestration.md`：
```markdown
---
globs: ["**/*"]
---

对于复杂任务（超过 3 个步骤），自动使用 Task Orchestration 工作流。
参考: ~/.claude/workflows/task-orchestration/
```

## 核心概念

### Agent 隔离
每个 Worker 使用 `isolation: "worktree"` 运行：
- 独立 git 工作树
- 独立文件状态
- 完成后自动清理

### 记忆压缩
Archiver 阶段将所有 Worker 记忆压缩为：
- 项目规范文档
- Agent 最佳实践
- 约束规则

### 交叉验证
Worker 总结 ↔ Reviewer 报告 ↔ Archiver 规范
三重验证确保一致性。
