# Task Orchestration Workflow

全局任务编排系统，用于管理多 Agent 协作任务。

## 快速开始

```
/orchestrate <任务描述>
```

## 工作流阶段

| 阶段 | Agent | 职责 | 输出 |
|------|-------|------|------|
| 1 | Orchestrator | 任务分解、框架生成 | task-framework.md |
| 2 | Worker-N | 执行子任务、验证、审查、总结 | task-report-N.md |
| 3 | Reviewer | 审查所有输出、验证一致性 | review-report.md |
| 4 | Archiver | 交叉验证、压缩记忆、生成规范 | project-spec.md |

## Agent 隔离机制

每个 Worker Agent 运行在独立 worktree 中：
- 隔离的文件系统
- 隔离的 git 状态
- 隔离的记忆上下文

## 规范文档结构

```yaml
project:
  name: ""
  path: ""
  tech_stack: []
  structure: {}

agents:
  - name: ""
    responsibility: ""
    skills: []
    tools: []

constraints:
  - rule: ""
    applies_to: []
```
