# 任务报告模板

任务ID: {{task_id}}
Worker: {{worker_id}}
完成时间: {{timestamp}}

## 1. 执行摘要

{{execution_summary}}

## 2. 验证结果

| 验收标准 | 状态 | 说明 |
|----------|------|------|
| {{criteria}} | ✅/❌ | {{result}} |

**测试结果:**
```
{{test_output}}
```

## 3. 审查发现

### 代码质量
- 评分: {{quality_score}}/10
- 说明: {{quality_notes}}

### 安全性
- 评分: {{security_score}}/10
- 说明: {{security_notes}}

### 性能
- 评分: {{performance_score}}/10
- 说明: {{performance_notes}}

## 4. 资源使用

### Skills 调用
| Skill | 用途 | 效果 |
|-------|------|------|
| {{skill_name}} | {{usage}} | {{effect}} |

### Tools 调用
| Tool | 次数 | 说明 |
|------|------|------|
| {{tool_name}} | {{count}} | {{notes}} |

## 5. 文件变更

| 文件 | 操作 | 说明 |
|------|------|------|
| {{file_path}} | 创建/修改/删除 | {{change_desc}} |

## 6. 遗留问题

| 问题 | 优先级 | 建议 |
|------|--------|------|
| {{issue}} | P1/P2/P3 | {{suggestion}} |

## 7. 记忆要点

{{memory_points}}

## 8. 下一步建议

{{next_steps}}
