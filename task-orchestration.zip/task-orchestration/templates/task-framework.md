# 任务框架模板

任务名称: {{task_name}}
创建时间: {{timestamp}}
创建者: Orchestrator

## 1. 任务概述

{{task_description}}

## 2. 子任务分解

### SUB-001: {{subtask_name}}

| 属性 | 值 |
|------|-----|
| 目标 | {{objective}} |
| 依赖 | {{dependencies}} |
| Agent类型 | {{agent_type}} |
| Skills | {{skills}} |
| Tools | {{tools}} |
| 预估时间 | {{estimated_time}} |

**验收标准:**
- [ ] {{acceptance_criteria_1}}
- [ ] {{acceptance_criteria_2}}

**详细说明:**
{{details}}

---

### SUB-002: ...

## 3. 依赖关系图

```
SUB-001 (无依赖)
    ↓
SUB-002 (依赖 SUB-001)
    ↓
SUB-003 (依赖 SUB-002)
```

## 4. 资源分配

| Agent | 子任务 | 并行度 |
|-------|--------|--------|
| Worker-1 | SUB-001 | 可并行 |
| Worker-2 | SUB-002 | 需等待 SUB-001 |

## 5. 风险评估

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| {{risk}} | {{impact}} | {{mitigation}} |
