# 项目技术规范

项目名称: {{project_name}}
版本: {{version}}
生成时间: {{timestamp}}
生成者: Archiver Agent

---

## 1. 项目概述

### 1.1 基本信息

| 属性 | 值 |
|------|-----|
| 项目名称 | {{project_name}} |
| 本地路径 | {{local_path}} |
| Git 仓库 | {{git_repo}} |
| 主分支 | {{main_branch}} |

### 1.2 功能模块

| 模块名称 | 职责描述 | 入口文件 | 负责Agent |
|----------|----------|----------|-----------|
| {{module_name}} | {{responsibility}} | {{entry_file}} | {{agent}} |

---

## 2. 项目结构

```
{{project_name}}/
├── src/
│   ├── modules/
│   │   ├── {{module_1}}/
│   │   └── {{module_2}}/
│   ├── utils/
│   └── index.ts
├── tests/
├── docs/
├── .claude/
│   └── rules/
└── PROJECT-SPEC.md
```

---

## 3. 技术栈

### 3.1 核心技术

| 类别 | 技术 | 版本 | 用途 |
|------|------|------|------|
| 语言 | {{language}} | {{version}} | {{purpose}} |
| 框架 | {{framework}} | {{version}} | {{purpose}} |
| 数据库 | {{database}} | {{version}} | {{purpose}} |

### 3.2 开发工具

| 工具 | 用途 |
|------|------|
| {{tool}} | {{purpose}} |

---

## 4. Agent 责任矩阵

### 4.1 标准配置

| Agent | 职责 | Skills | Tools | 触发条件 |
|-------|------|--------|-------|----------|
| Orchestrator | 任务分解与编排 | task-create | Agent, TaskCreate, Write | 接收复杂任务 |
| Worker | 执行子任务 | {{skills}} | Read, Edit, Write, Bash, Grep | 被分配任务 |
| Reviewer | 审查验证 | review, simplify | Read, Grep | 所有 Worker 完成 |
| Archiver | 归档规范 | simplify | Read, Write | 审查通过 |

### 4.2 Worker 专业化配置

| Worker 类型 | 适用场景 | 专属 Skills |
|-------------|----------|-------------|
| Worker-Frontend | UI/UX 任务 | playwright-skill |
| Worker-Backend | API/逻辑任务 | claude-api |
| Worker-Security | 安全审查 | security-review |

---

## 5. 工作流约束

### 5.1 全局规则

1. **任务分解规则**
   - 复杂度 > 3 步必须分解
   - 每个子任务单一职责
   - 明确标注依赖关系

2. **质量门禁**
   - 代码质量分 >= 7/10
   - 安全性分 >= 8/10
   - 性能分 >= 6/10
   - 所有验收标准必须通过

3. **隔离规则**
   - Worker 必须使用 worktree 隔离
   - 完成后清理临时文件
   - 不共享内存上下文

### 5.2 文档规范

| 文档类型 | 路径 | 模板 |
|----------|------|------|
| 任务框架 | `.claude/workspace/task-framework.md` | task-framework.md |
| 任务报告 | `.claude/workspace/task-report-*.md` | task-report.md |
| 项目规范 | `.claude/rules/project-spec.md` | project-spec.md |

### 5.3 命名规范

| 类型 | 规则 | 示例 |
|------|------|------|
| 子任务ID | SUB-XXX | SUB-001 |
| Worker ID | Worker-N | Worker-1 |
| 报告文件 | task-report-XXX.md | task-report-001.md |

---

## 6. 质量检查清单

### 6.1 代码提交前

- [ ] 所有测试通过
- [ ] 无 lint 错误
- [ ] 无安全漏洞
- [ ] 文档已更新

### 6.2 任务完成前

- [ ] 验收标准全部通过
- [ ] 报告完整填写
- [ ] 遗留问题已记录
- [ ] 记忆要点已提取

---

## 7. 历史版本

| 版本 | 日期 | 变更说明 | 触发任务 |
|------|------|----------|----------|
| {{version}} | {{date}} | {{change_desc}} | {{task_id}} |

---

## 8. 附录

### 8.1 常用命令

```bash
# 启动编排
/orchestrate <任务描述>

# 查看任务状态
/task-list

# 手动触发审查
/review

# 更新规范
/update-spec
```

### 8.2 参考资源

- 工作流文档: `~/.claude/workflows/task-orchestration/`
- 提示词模板: `~/.claude/workflows/task-orchestration/prompts/`
- 文档模板: `~/.claude/workflows/task-orchestration/templates/`
