# Task Orchestration Skill

在接收到任务时，自动启动多 Agent 编排工作流。

## 触发
```
/orchestrate <任务描述>
```

## 执行流程

### Phase 1: 框架生成
1. 分析任务复杂度
2. 分解为子任务
3. 生成 `task-framework.md`
4. 创建 Task 跟踪条目

### Phase 2: 任务分发
对每个子任务并行启动 Worker Agent：
```
Agent({
  subagent_type: "general-purpose",
  isolation: "worktree",
  prompt: "[WORKER PROMPT] + [子任务详情]",
  mode: "default"
})
```

### Phase 3: 审查验证
所有 Worker 完成后启动 Reviewer Agent：
```
Agent({
  subagent_type: "general-purpose",
  prompt: "[REVIEWER PROMPT] + [报告路径]",
  mode: "default"
})
```

### Phase 4: 归档
审查通过后启动 Archiver Agent：
```
Agent({
  subagent_type: "general-purpose",
  prompt: "[ARCHIVER PROMPT] + [所有文档路径]",
  mode: "default"
})
```

## 使用示例

```
用户: /orchestrate 实现用户认证模块，包含注册、登录、密码重置功能

Orchestrator: 
1. 生成框架，分解为 4 个子任务
2. 启动 4 个隔离 Worker
3. 收集报告，启动 Reviewer
4. 审查通过，启动 Archiver
5. 生成 project-spec.md
```

## 配置

在 `.claude/settings.json` 中：
```json
{
  "taskOrchestration": {
    "maxParallelWorkers": 4,
    "qualityThreshold": 7,
    "securityThreshold": 8,
    "autoArchive": true
  }
}
```
