# 快速启动指南

## 1. 基础配置

在 `~/.claude/settings.json` 中添加:

```json
{
  "taskOrchestration": {
    "enabled": true,
    "maxParallelWorkers": 4,
    "qualityThreshold": 7,
    "securityThreshold": 8,
    "performanceThreshold": 6,
    "autoArchive": true,
    "workspaceDir": ".claude/workspace"
  }
}
```

## 2. 项目级配置

在项目 `.claude/rules/project-spec.md` 中定义项目专属规则:

```markdown
# 项目技术规范

## Agent 配置
- Worker-Frontend: 处理 UI 相关任务
- Worker-Backend: 处理 API/逻辑任务
- Worker-Test: 处理测试相关任务

## 约束
- 所有 API 必须有单元测试
- 提交前运行 lint
- 使用项目模板目录
```

## 3. 使用方式

### 方式 A: 手动触发
```
/orchestrate <任务描述>
```

### 方式 B: 自动触发

在 `.claude/rules/auto-orchestrate.md`:

```markdown
---
globs: ["**/*"]
---

复杂任务规则:
- 步骤数 > 3: 自动使用 orchestrate
- 涉及多个模块: 自动分解
- 需要跨文件修改: 启动隔离 Worker
```

## 4. 工作流监控

```
/task-list          # 查看当前任务状态
/task-output <id>   # 查看任务输出
/task-stop <id>     # 停止任务
```

## 5. 输出文件

| 文件 | 说明 | 何时生成 |
|------|------|----------|
| task-framework.md | 任务分解框架 | Phase 1 |
| task-report-*.md | 子任务报告 | Phase 2 |
| review-report.md | 审查报告 | Phase 3 |
| project-spec.md | 项目规范 | Phase 4 |
