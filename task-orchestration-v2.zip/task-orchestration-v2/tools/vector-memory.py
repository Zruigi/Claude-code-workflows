#!/usr/bin/env python3
# vector-memory.py — Local Vector Memory Engine for Agents
# Install: pip install chromadb sentence-transformers
# Run: python vector-memory.py <command> [args]

import json
import sys
import os
from datetime import datetime
from pathlib import Path

# Fix Windows GBK encoding issues
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer


class VectorMemoryEngine:
    """ChromaDB-backed local vector memory for Agent factor storage and retrieval."""

    def __init__(self, project_root: str = None):
        self.root = Path(project_root or Path.cwd())
        self.store_path = self.root / ".claude" / "memory" / "vector-store"
        self.store_path.mkdir(parents=True, exist_ok=True)

        self.client = chromadb.PersistentClient(
            path=str(self.store_path),
            settings=Settings(anonymized_telemetry=False),
        )

        self.model = SentenceTransformer("all-MiniLM-L6-v2")

        self.factors = self.client.get_or_create_collection(
            name="factors", metadata={"hnsw:space": "cosine"}
        )

        self.events = self.client.get_or_create_collection(
            name="events", metadata={"hnsw:space": "cosine"}
        )

    # ── store ──────────────────────────────────────────────
    def store_factor(self, factor: dict) -> str:
        text = self._factor_to_text(factor)
        embedding = self.model.encode(text).tolist()

        files_replaced = factor.get("impact", {}).get("replacesFiles", [])
        files_created = factor.get("result", {}).get("artifacts", {}).get("created", [])

        meta = {
            "cause_type": factor.get("cause", {}).get("type", ""),
            "language": factor.get("process", {}).get("language", ""),
            "framework": factor.get("process", {}).get("framework", ""),
            "files_created": json.dumps(files_created)[:800],
            "files_replaced": json.dumps(files_replaced)[:800],
            "task_id": factor.get("taskId", ""),
            "timestamp": factor.get("timestamp", ""),
            "agent_type": factor.get("agentType", ""),
        }

        # ChromaDB strings only
        for k in ("files_created", "files_replaced"):
            if k in meta and len(meta[k]) > 1000:
                meta[k] = meta[k][:1000]

        self.factors.add(
            ids=[factor.get("factorId")],
            embeddings=[embedding],
            metadatas=[meta],
            documents=[text[:2000]],
        )
        return factor.get("factorId")

    # ── search ─────────────────────────────────────────────
    def search_similar(self, query: str, n: int = 5, cause_type: str = None):
        embedding = self.model.encode(query).tolist()
        where = {"cause_type": cause_type} if cause_type else None

        results = self.factors.query(
            query_embeddings=[embedding], n_results=n, where=where
        )

        out = []
        for i, fid in enumerate(results["ids"][0]):
            out.append(
                {
                    "id": fid,
                    "distance": results["distances"][0][i],
                    "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                    "document": results["documents"][0][i],
                }
            )
        return out

    # ── debt ───────────────────────────────────────────────
    def find_code_debt(self):
        try:
            all_data = self.factors.get()
        except Exception:
            return []

        debt = []
        ids = all_data.get("ids", [])
        metas = all_data.get("metadatas", []) if all_data.get("metadatas") else []
        docs = all_data.get("documents", []) if all_data.get("documents") else []

        for i, fid in enumerate(ids):
            meta = metas[i] if i < len(metas) else {}
            replaced_str = meta.get("files_replaced", "[]")
            created_str = meta.get("files_created", "[]")
            try:
                replaced = json.loads(replaced_str)
            except Exception:
                replaced = []
            try:
                created = json.loads(created_str)
            except Exception:
                created = []

            if replaced:
                for rf in replaced:
                    if rf not in created:
                        debt.append(
                            {
                                "factor_id": fid,
                                "replaced_file": rf,
                                "new_files": created,
                                "document": docs[i] if i < len(docs) else "",
                            }
                        )
        return debt

    # ── related ────────────────────────────────────────────
    def find_related(self, file_path: str):
        results = self.factors.get(
            where={"files_replaced": {"$contains": file_path}}
        )
        return {
            "ids": results.get("ids", []),
            "documents": results.get("documents", []),
        }

    # ── stats ──────────────────────────────────────────────
    def stats(self):
        all_data = self.factors.get()
        ids = all_data.get("ids", [])
        metas = all_data.get("metadatas", []) if all_data.get("metadatas") else []

        cause_counts = {}
        lang_counts = {}
        for m in metas:
            ct = m.get("cause_type", "unknown")
            cause_counts[ct] = cause_counts.get(ct, 0) + 1
            lg = m.get("language", "unknown")
            lang_counts[lg] = lang_counts.get(lg, 0) + 1

        return {"total_factors": len(ids), "cause_types": cause_counts, "languages": lang_counts}

    # ── helpers ────────────────────────────────────────────
    def _factor_to_text(self, factor: dict) -> str:
        cause = factor.get("cause", {})
        process = factor.get("process", {})
        impact = factor.get("impact", {})

        parts = [
            f"Cause: {cause.get('type', '')} - {cause.get('description', '')}",
            f"Trigger: {cause.get('trigger', '')}",
            f"Language: {process.get('language', '')}",
            f"Framework: {process.get('framework', '')}",
            f"Pattern: {process.get('pattern', '')}",
            f"Files created: {', '.join(process.get('filesCreated', []))}",
            f"Files modified: {', '.join(process.get('filesModified', []))}",
            f"Files deleted: {', '.join(process.get('filesDeleted', []))}",
            f"Files replaced: {', '.join(impact.get('replacesFiles', []))}",
            f"Functions replaced: {', '.join(impact.get('replacesFunctions', []))}",
            f"Affected callers: {', '.join(impact.get('affectedCallers', []))}",
            f"Migration required: {'yes' if impact.get('migrationRequired') else 'no'}",
            f"Deprecation: {impact.get('deprecationNotice', '')}",
        ]
        return "; ".join(parts)


# ── CLI ────────────────────────────────────────────────────
if __name__ == "__main__":
    engine = VectorMemoryEngine()

    if len(sys.argv) < 2:
        print("Usage: python vector-memory.py <command> [args]")
        print("Commands: search debt related store stats init")
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == "search":
        query = " ".join(sys.argv[2:]) or "refactoring"
        results = engine.search_similar(query, n=5)
        for r in results:
            dist = r["distance"]
            doc = r["document"][:120]
            print(f"  {r['id']} (sim={dist:.3f}) {doc}")

    elif cmd == "debt":
        debt = engine.find_code_debt()
        if not debt:
            print("  No code debt found.")
        for d in debt:
            print(f"  [WARN] {d['replaced_file']} → replaced, not yet deleted (factor: {d['factor_id']})")
            if d["new_files"]:
                print(f"    new: {', '.join(d['new_files'])}")

    elif cmd == "related":
        if len(sys.argv) < 3:
            print("Usage: python vector-memory.py related <file_path>")
            sys.exit(1)
        file_path = sys.argv[2]
        results = engine.find_related(file_path)
        for i, fid in enumerate(results["ids"]):
            doc = results["documents"][i][:100] if i < len(results["documents"]) else ""
            print(f"  {fid}: {doc}")

    elif cmd == "store":
        if len(sys.argv) < 3:
            print("Usage: python vector-memory.py store <factor.json>")
            sys.exit(1)
        with open(sys.argv[2], encoding="utf-8") as f:
            factor = json.load(f)
        fid = engine.store_factor(factor)
        print(f"  Stored factor: {fid}")

    elif cmd == "stats":
        s = engine.stats()
        print(json.dumps(s, indent=2, ensure_ascii=False))

    elif cmd == "init":
        engine.store_path.mkdir(parents=True, exist_ok=True)
        print(f"  Vector store initialized at: {engine.store_path}")
        s = engine.stats()
        print(f"  Factors in database: {s['total_factors']}")

    else:
        print(f"Unknown command: {cmd}")
        print("Commands: search debt related store stats init")
