# debt-check.ps1
# 扫描因子图谱，列出所有"被替代但未清理"的代码

param(
    [string]$ProjectRoot = $PWD.Path
)

$enginePath = Join-Path $ProjectRoot ".claude\tools\vector-memory.py"
$factorsFile = Join-Path $ProjectRoot ".claude\memory\decisions\factors.jsonl"

Write-Host "=== Code Debt Report ==="
Write-Host ""
Write-Host "[1/2] Vector store debt scan..."

if (Test-Path $enginePath) {
    python $enginePath debt
} else {
    Write-Host "  Vector engine not installed. Skipping."
}

Write-Host ""
Write-Host "[2/2] Deprecation notices..."

if (Test-Path $factorsFile) {
    $overdue = @()
    $pending = @()

    Get-Content $factorsFile | ForEach-Object {
        try {
            $factor = $_ | ConvertFrom-Json
            $notice = $factor.impact.deprecationNotice
            $deadline = $factor.impact.cleanupDeadline

            if ($notice -and $deadline) {
                $daysLeft = ([DateTime]$deadline - (Get-Date)).Days
                if ($daysLeft -lt 0) {
                    $overdue += @{ Id = $factor.factorId; Notice = $notice; DaysOverdue = -$daysLeft }
                } else {
                    $pending += @{ Id = $factor.factorId; Notice = $notice; DaysLeft = $daysLeft }
                }
            } elseif ($notice) {
                Write-Host "  ⚠ $($factor.factorId): $notice (no deadline set)"
            }
        } catch {}
    }

    if ($overdue.Count -gt 0) {
        Write-Host ""
        Write-Host "  === OVERDUE CLEANUP ==="
        foreach ($o in $overdue) {
            Write-Host "  ❌ $($o.Id): $($o.Notice) — $($o.DaysOverdue) days overdue"
        }
    }

    if ($pending.Count -gt 0) {
        Write-Host ""
        Write-Host "  === PENDING CLEANUP ==="
        foreach ($p in $pending) {
            Write-Host "  ⏳ $($p.Id): $($p.Notice) — $($p.DaysLeft) days left"
        }
    }

    if ($overdue.Count -eq 0 -and $pending.Count -eq 0) {
        Write-Host "  No deprecation notices found."
    }
} else {
    Write-Host "  No factors file found."
}
