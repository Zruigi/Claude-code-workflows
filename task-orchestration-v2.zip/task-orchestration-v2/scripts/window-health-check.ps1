# window-health-check.ps1
# 扫描心跳过期窗口，回收未完成任务

param(
    [string]$ProjectRoot = $PWD.Path,
    [int]$StaleThresholdMs = 30000,
    [int]$OfflineThresholdMs = 90000,
    [int]$DeadThresholdMs = 180000
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$stateFile = Join-Path $workspace "state.json"
$assignmentsFile = Join-Path $workspace "assignments.json"

if (-not (Test-Path $stateFile)) {
    Write-Warning "state.json not found. Nothing to check."
    exit 0
}

$now = Get-Date
$nowIso = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"
$state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
$changed = $false

foreach ($winId in $state.windows.PSObject.Properties.Name) {
    if ($winId -eq "main") { continue }  # Skip main window

    $win = $state.windows.$winId
    if (-not $win.lastHeartbeatAt) { continue }

    $timeSinceHeartbeat = ($now - [DateTime]::Parse($win.lastHeartbeatAt)).TotalMilliseconds

    if ($timeSinceHeartbeat -gt $DeadThresholdMs) {
        Write-Warning "Window $winId DEAD (${timeSinceHeartbeat}ms). Reclaiming tasks."
        $state.windows.$winId.status = "offline"

        # Reclaim all running tasks
        if ($win.runningTasks.Count -gt 0 -and (Test-Path $assignmentsFile)) {
            $assignments = Get-Content $assignmentsFile -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($taskId in $win.runningTasks) {
                Write-Host "  Reclaiming: $taskId"
                if ($assignments.assignments.PSObject.Properties[$taskId]) {
                    $task = $assignments.assignments.$taskId
                    $task.status = "unassigned"
                    $task.leaseExpiresAt = $null
                    $task.retryCount = ($task.retryCount + 1)
                    if ($task.retryCount -ge 3) {
                        $task.status = "failed"
                        Write-Warning "    Max retries reached. Marking failed."
                    }
                    $state.summary.running = [Math]::Max(0, ($state.summary.running - 1))
                    $state.summary.pending = [Math]::Max(0, ($state.summary.pending + 1))
                }
            }
            $assignments.updatedAt = $nowIso
            $assignments | ConvertTo-Json -Depth 10 | Set-Content $assignmentsFile -Encoding UTF8
        }
        $state.windows.$winId.runningTasks = @()
        $changed = $true

    } elseif ($timeSinceHeartbeat -gt $OfflineThresholdMs) {
        Write-Warning "Window $winId OFFLINE (${timeSinceHeartbeat}ms)."
        if ($state.windows.$winId.status -ne "offline") {
            $state.windows.$winId.status = "offline"
            $changed = $true
        }

    } elseif ($timeSinceHeartbeat -gt $StaleThresholdMs) {
        Write-Warning "Window $winId STALE (${timeSinceHeartbeat}ms)."
        if ($state.windows.$winId.status -ne "stale") {
            $state.windows.$winId.status = "stale"
            $changed = $true
        }
    }
}

if ($changed) {
    $state.updatedAt = $nowIso
    $state | ConvertTo-Json -Depth 10 | Set-Content $stateFile -Encoding UTF8
    Write-Host "State updated."
} else {
    Write-Host "All windows healthy."
}
