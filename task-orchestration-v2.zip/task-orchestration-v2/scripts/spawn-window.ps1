# spawn-window.ps1
# 判断是否需要新窗口，如需则启动

param(
    [string]$ProjectRoot = $PWD.Path,
    [int]$MainCapacity = 4,
    [int]$SubCapacity = 2,
    [int]$MaxWindows = 4,
    [int]$MaxSpawnAttempts = 3
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$stateFile = Join-Path $workspace "state.json"

if (-not (Test-Path $stateFile)) {
    Write-Error "state.json not found. Run init-workspace-state.ps1 first."
    exit 1
}

$state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json

# Calculate available slots
$availableSlots = 0
$activeWindows = 0
$windowIds = @()

foreach ($winId in $state.windows.PSObject.Properties.Name) {
    $win = $state.windows.$winId
    if ($win.status -ne "offline") {
        $activeWindows++
        $windowIds += $winId
        $used = $win.runningTasks.Count
        $free = $win.capacity - $used
        if ($free -gt 0) { $availableSlots += $free }
    }
}

# Get pending tasks from assignments
$assignmentsFile = Join-Path $workspace "assignments.json"
$pendingCount = 0
if (Test-Path $assignmentsFile) {
    $assignments = Get-Content $assignmentsFile -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($taskId in $assignments.assignments.PSObject.Properties.Name) {
        $task = $assignments.assignments.$taskId
        if ($task.status -eq "unassigned" -or $task.status -eq "pending") {
            $pendingCount++
        }
    }
}

Write-Host "Windows: $activeWindows/$MaxWindows | Available slots: $availableSlots | Pending: $pendingCount"

# Exit if no pending tasks
if ($pendingCount -eq 0) {
    Write-Host "No pending tasks. Skipping spawn."
    exit 0
}

# Exit if enough slots
if ($availableSlots -ge $pendingCount) {
    Write-Host "Sufficient slots available. No new window needed."
    exit 0
}

# Exit if max windows reached
if ($activeWindows -ge $MaxWindows) {
    Write-Host "Max windows ($MaxWindows) reached. Cannot spawn."
    exit 0
}

# Spawn new window
$nextWindowId = "window-{0}" -f ($activeWindows + 1)
Write-Host "Spawning new window: $nextWindowId"

# Check spawn attempts
$attemptsFile = Join-Path $workspace "logs" "spawn-attempts.json"
$attempts = @{}
if (Test-Path $attemptsFile) {
    $attempts = Get-Content $attemptsFile -Raw -Encoding UTF8 | ConvertFrom-Json
}

$currentAttempts = 0
if ($attempts.PSObject.Properties[$nextWindowId]) {
    $currentAttempts = $attempts.$nextWindowId.count
}

if ($currentAttempts -ge $MaxSpawnAttempts) {
    Write-Warning "Max spawn attempts ($MaxSpawnAttempts) reached for $nextWindowId. Degrading to single-window."
    exit 1
}

# Record attempt
if (-not $attempts.PSObject.Properties[$nextWindowId]) {
    $attempts | Add-Member -NotePropertyName $nextWindowId -NotePropertyValue @() -Force
}
$attempts.$nextWindowId += (Get-Date -Format "yyyy-MM-ddTHH:mm:ssK")
$attempts | ConvertTo-Json -Depth 5 | Set-Content $attemptsFile -Encoding UTF8

# Start new window
$registerScript = Join-Path $PSScriptRoot "register-window.ps1"
$claudeCodeArgs = @(
    "--new-window",
    "--directory", $ProjectRoot,
    "--prompt", "Register as $nextWindowId. Run: powershell -File `"$registerScript`" -WindowId `"$nextWindowId`" -ProjectRoot `"$ProjectRoot`"; then begin executing assigned tasks."
)

try {
    $claudeBinary = if (Get-Command "claude-code" -ErrorAction SilentlyContinue) { "claude-code" } else { "claude" }
    Start-Process $claudeBinary -ArgumentList $claudeCodeArgs
    Write-Host "Window $nextWindowId spawned (using: $claudeBinary)."
} catch {
    Write-Error "Failed to spawn window $nextWindowId : $_"
    exit 1
}
