# reconcile-state.ps1
# 汇总 reports / assignments / windows 状态，修正 state.json

param(
    [string]$ProjectRoot = $PWD.Path
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$frameworkFile = Join-Path $workspace "framework.json"
$assignmentsFile = Join-Path $workspace "assignments.json"
$stateFile = Join-Path $workspace "state.json"
$reportsDir = Join-Path $workspace "reports"

$files = @($frameworkFile, $assignmentsFile, $stateFile)
foreach ($f in $files) {
    if (-not (Test-Path $f)) {
        Write-Error "Missing: $f"
        exit 1
    }
}

$framework = Get-Content $frameworkFile -Raw -Encoding UTF8 | ConvertFrom-Json
$assignments = Get-Content $assignmentsFile -Raw -Encoding UTF8 | ConvertFrom-Json
$state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
$now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"

# Recalculate summary from assignments
$summary = @{
    totalSubtasks = 0
    pending = 0
    running = 0
    completed = 0
    failed = 0
    blocked = 0
}

$seen = @{}
foreach ($taskId in $assignments.assignments.PSObject.Properties.Name) {
    $status = $assignments.assignments.$taskId.status
    $summary.totalSubtasks++
    if ($status -eq "unassigned") { $summary.pending++ }
    elseif ($status -eq "claimed") { $summary.pending++ }
    elseif ($status -eq "running") { $summary.running++ }
    elseif ($status -eq "completed") { $summary.completed++ }
    elseif ($status -eq "failed") { $summary.failed++ }
    elseif ($status -eq "blocked") { $summary.blocked++ }
    $seen[$taskId] = $true
}

# Also count framework subtasks not yet in assignments
foreach ($subtask in $framework.subtasks) {
    if (-not $seen.ContainsKey($subtask.id)) {
        $summary.totalSubtasks++
        $summary.pending++
    }
}

# Check reports
if (Test-Path $reportsDir) {
    $reports = Get-ChildItem $reportsDir -Filter "*.json"
    foreach ($report in $reports) {
        try {
            $data = Get-Content $report.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $taskId = $data.subtaskId
            if ($data.status -eq "completed" -and $seen.ContainsKey($taskId)) {
                # Verify assignment matches report
                $assignmentStatus = $assignments.assignments.$taskId.status
                if ($assignmentStatus -ne "completed") {
                    Write-Warning "Mismatch: $taskId report=completed, assignment=$assignmentStatus"
                }
            }
        } catch {
            Write-Warning "Failed to parse report: $($report.Name)"
        }
    }
}

# Update state summary
$state.summary = $summary
$state.updatedAt = $now

# Clean expired leases
foreach ($taskId in $assignments.assignments.PSObject.Properties.Name) {
    $task = $assignments.assignments.$taskId
    if ($task.status -in @("claimed", "running") -and $task.leaseExpiresAt) {
        $leaseExpires = [DateTime]::Parse($task.leaseExpiresAt)
        if ((Get-Date) -gt $leaseExpires) {
            Write-Warning "Lease expired for $taskId. Reverting to pending."
            $assignments.assignments.$taskId.status = "unassigned"
            $assignments.assignments.$taskId.leaseExpiresAt = $null
        }
    }
}

# Clean stale windows
foreach ($winId in $state.windows.PSObject.Properties.Name) {
    $win = $state.windows.$winId
    if ($win.lastHeartbeatAt) {
        $timeSinceHeartbeat = ((Get-Date) - [DateTime]::Parse($win.lastHeartbeatAt)).TotalMilliseconds
        if ($timeSinceHeartbeat -gt 180000 -and $winId -ne "main") {
            Write-Warning "Window $winId dead (no heartbeat). Marking offline."
            $state.windows.$winId.status = "offline"
            # Reclaim running tasks
            foreach ($taskId in $win.runningTasks) {
                if ($assignments.assignments.PSObject.Properties[$taskId]) {
                    $assignments.assignments.$taskId.status = "unassigned"
                }
            }
            $win.runningTasks = @()
        } elseif ($timeSinceHeartbeat -gt 90000 -and $winId -ne "main") {
            Write-Warning "Window $winId offline. Marking offline."
            $state.windows.$winId.status = "offline"
        } elseif ($timeSinceHeartbeat -gt 30000 -and $winId -ne "main") {
            Write-Warning "Window $winId stale."
            if ($state.windows.$winId.status -ne "stale") {
                $state.windows.$winId.status = "stale"
            }
        }
    }
}

# Save
$state | ConvertTo-Json -Depth 10 | Set-Content $stateFile -Encoding UTF8
$assignments.updatedAt = $now
$assignments | ConvertTo-Json -Depth 10 | Set-Content $assignmentsFile -Encoding UTF8

Write-Host "Reconciled. Summary: $($summary.pending)p $($summary.running)r $($summary.completed)c $($summary.failed)f $($summary.blocked)b"
