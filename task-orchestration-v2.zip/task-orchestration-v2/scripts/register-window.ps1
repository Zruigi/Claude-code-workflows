# register-window.ps1
# 新窗口注册到 state.json

param(
    [string]$WindowId,
    [string]$ProjectRoot = $PWD.Path
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$stateFile = Join-Path $workspace "state.json"

if (-not $WindowId -or $WindowId -eq "main") {
    Write-Error "Invalid WindowId. Must be non-main ID (e.g. window-2)."
    exit 1
}

if (-not (Test-Path $stateFile)) {
    Write-Error "state.json not found."
    exit 1
}

# Read state
$state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json

# Check if window already registered
if ($state.windows.PSObject.Properties[$WindowId]) {
    Write-Host "Window $WindowId already registered. Updating heartbeat."
    $state.windows.$WindowId.lastHeartbeatAt = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"
    $state.windows.$WindowId.status = "idle"
} else {
    # Register new window
    $now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"
    $windowInfo = @{
        status = "idle"
        pid = $PID
        role = "worker-host"
        capacity = 2
        runningTasks = @()
        lastHeartbeatAt = $now
        startedAt = $now
        cwd = $ProjectRoot
    }
    $state.windows | Add-Member -NotePropertyName $WindowId -NotePropertyValue $windowInfo -Force
    Write-Host "Window $WindowId registered."
}

$state.updatedAt = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"
$state | ConvertTo-Json -Depth 10 | Set-Content $stateFile -Encoding UTF8
Write-Host "Registration complete. Status: idle"
