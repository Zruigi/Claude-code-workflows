# heartbeat.ps1
# 更新窗口和任务心跳到 state.json

param(
    [string]$WindowId = "main",
    [string]$ProjectRoot = $PWD.Path,
    [string[]]$TaskIds = @()
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$stateFile = Join-Path $workspace "state.json"

if (-not (Test-Path $stateFile)) {
    Write-Error "state.json not found."
    exit 1
}

$now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"
$state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json

# Update window heartbeat
if ($state.windows.PSObject.Properties[$WindowId]) {
    $state.windows.$WindowId.lastHeartbeatAt = $now
    if ($state.windows.$WindowId.status -eq "stale") {
        $state.windows.$WindowId.status = "idle"
        Write-Host "Window $WindowId recovered from stale."
    }
}

# Update task heartbeats
foreach ($taskId in $TaskIds) {
    if ($state.subtasks.PSObject.Properties[$taskId]) {
        $state.subtasks.$taskId.lastHeartbeatAt = $now
    }
}

$state.updatedAt = $now
$state | ConvertTo-Json -Depth 10 | Set-Content $stateFile -Encoding UTF8
Write-Host "Heartbeat updated: $WindowId $now"
