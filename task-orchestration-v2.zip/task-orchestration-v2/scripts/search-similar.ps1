# search-similar.ps1
# 检索与当前任务相似的历史因子

param(
    [string]$Query,
    [string]$ProjectRoot = $PWD.Path
)

$enginePath = Join-Path $ProjectRoot ".claude\tools\vector-memory.py"

if (-not (Test-Path $enginePath)) {
    Write-Warning "Vector memory engine not installed. Run setup-vector-memory.ps1 first."
    exit 0
}

Write-Host "=== Similar Factors ==="
python $enginePath search $Query
