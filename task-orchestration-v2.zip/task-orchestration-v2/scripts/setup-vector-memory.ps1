# setup-vector-memory.ps1
# 安装向量记忆引擎依赖

param(
    [string]$ProjectRoot = $PWD.Path
)

$toolsDir = Join-Path $ProjectRoot ".claude\tools"
$templateDir = Join-Path $env:USERPROFILE ".claude\workflows\task-orchestration-v2\tools"

# Create tools directory
if (-not (Test-Path $toolsDir)) {
    New-Item -ItemType Directory -Path $toolsDir -Force | Out-Null
    Write-Host "Created: $toolsDir"
}

# Copy vector-memory.py from template
if (-not (Test-Path (Join-Path $toolsDir "vector-memory.py"))) {
    $source = Join-Path $templateDir "vector-memory.py"
    if (Test-Path $source) {
        Copy-Item $source $toolsDir
        Write-Host "Copied vector-memory.py to .claude/tools/"
    } else {
        Write-Warning "Template not found: $source"
    }
}

# Install Python dependencies
Write-Host "Installing Python dependencies..."
pip install chromadb sentence-transformers -q 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Error "pip install failed. Please install manually: pip install chromadb sentence-transformers"
    exit 1
}

Write-Host "Dependencies installed."

# Initialize vector store
$enginePath = Join-Path $toolsDir "vector-memory.py"
if (Test-Path $enginePath) {
    python $enginePath init
} else {
    Write-Warning "vector-memory.py not found after setup."
}
