# init-workspace-state.ps1
# 初始化运行时工作区文件

param(
    [string]$ProjectRoot = $PWD.Path,
    [string]$TaskId = "task-$(Get-Date -Format 'yyyy')-001",
    [string]$TaskName = "default-task"
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"

# Create directories
$dirs = @(
    $workspace,
    (Join-Path $workspace "reports"),
    (Join-Path $workspace "contracts"),
    (Join-Path $workspace "logs"),
    (Join-Path $workspace "events")
)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "Created: $dir"
    }
}

$now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"

# framework.json
$framework = @{
    version = "2.1"
    taskName = $TaskName
    taskDescription = ""
    complexityScore = 0
    createdAt = $now
    featureAnalysis = @{
        enabled = $false
        frontendFeatures = @()
        backendAPIs = @()
        apiContractPath = ""
        referenceCases = @()
    }
    subtasks = @()
    dependencyGraph = @{}
    execution = @{
        mode = "single-window"
        parallelCount = 0
        claudeInstances = @("main")
    }
    metadata = @{
        decompositionDepth = 1
        parallelizable = $true
    }
}
$frameworkJson = Join-Path $workspace "framework.json"
$framework | ConvertTo-Json -Depth 10 | Set-Content $frameworkJson -Encoding UTF8
Write-Host "Created: $frameworkJson"

# state.json
$state = @{
    version = "2.1"
    taskId = $TaskId
    status = "running"
    phase = "orchestrator"
    startedAt = $now
    updatedAt = $now
    heartbeatIntervalMs = 30000
    heartbeatTimeoutMs = 90000
    summary = @{
        totalSubtasks = 0
        pending = 0
        running = 0
        completed = 0
        failed = 0
        blocked = 0
    }
    windows = @{
        main = @{
            status = "busy"
            pid = $PID
            role = "orchestrator"
            capacity = 4
            runningTasks = @()
            lastHeartbeatAt = $now
            cwd = $ProjectRoot
        }
    }
    subtasks = @{}
}
$stateJson = Join-Path $workspace "state.json"
$state | ConvertTo-Json -Depth 10 | Set-Content $stateJson -Encoding UTF8
Write-Host "Created: $stateJson"

# assignments.json
$assignments = @{
    version = "2.1"
    taskId = $TaskId
    updatedAt = $now
    assignments = @{}
}
$assignmentsJson = Join-Path $workspace "assignments.json"
$assignments | ConvertTo-Json -Depth 10 | Set-Content $assignmentsJson -Encoding UTF8
Write-Host "Created: $assignmentsJson"

Write-Host "Workspace initialized: $TaskName ($TaskId)"
