# release-window.ps1
# 清空窗口 runningTasks，标记 idle/offline

param(
    [string]$WindowId,
    [string]$ProjectRoot = $PWD.Path,
    [switch]$Shutdown
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$stateFile = Join-Path $workspace "state.json"
$assignmentsFile = Join-Path $workspace "assignments.json"

if (-not (Test-Path $stateFile)) {
    Write-Error "state.json not found."
    exit 1
}

$now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"
$state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json

if (-not $state.windows.PSObject.Properties[$WindowId]) {
    Write-Warning "Window $WindowId not registered."
    exit 0
}

$win = $state.windows.$WindowId

# Reclaim running tasks
if ($win.runningTasks.Count -gt 0 -and (Test-Path $assignmentsFile)) {
    $assignments = Get-Content $assignmentsFile -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($taskId in $win.runningTasks) {
        if ($assignments.assignments.PSObject.Properties[$taskId]) {
            $assignments.assignments.$taskId.status = "unassigned"
            $assignments.assignments.$taskId.leaseExpiresAt = $null
            Write-Host "Reclaimed task: $taskId"
        }
    }
    $assignments.updatedAt = $now
    $assignments | ConvertTo-Json -Depth 10 | Set-Content $assignmentsFile -Encoding UTF8
}

# Update window status
$state.windows.$WindowId.runningTasks = @()
if ($Shutdown) {
    $state.windows.$WindowId.status = "offline"
    Write-Host "Window $WindowId shutdown. Status: offline"
} else {
    $state.windows.$WindowId.status = "idle"
    Write-Host "Window $WindowId released. Status: idle"
}

$state.updatedAt = $now
$state | ConvertTo-Json -Depth 10 | Set-Content $stateFile -Encoding UTF8
