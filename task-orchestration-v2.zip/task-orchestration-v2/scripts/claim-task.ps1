# claim-task.ps1
# 认领 pending 任务，检查依赖，写入 lease

param(
    [string]$TaskId,
    [string]$WindowId = "main",
    [string]$WorkerId = "worker-1",
    [string]$ProjectRoot = $PWD.Path,
    [int]$LeaseDurationSeconds = 600
)

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$frameworkFile = Join-Path $workspace "framework.json"
$assignmentsFile = Join-Path $workspace "assignments.json"
$stateFile = Join-Path $workspace "state.json"

if (-not (Test-Path $frameworkFile) -or -not (Test-Path $assignmentsFile)) {
    Write-Error "Framework or assignments not found."
    exit 1
}

$framework = Get-Content $frameworkFile -Raw -Encoding UTF8 | ConvertFrom-Json
$assignments = Get-Content $assignmentsFile -Raw -Encoding UTF8 | ConvertFrom-Json

# Check subtask exists
$subtask = $framework.subtasks | Where-Object { $_.id -eq $TaskId }
if (-not $subtask) {
    Write-Error "Task $TaskId not found in framework."
    exit 1
}

# Check dependencies completed
foreach ($depId in $subtask.dependencies) {
    $depStatus = "pending"
    if ($assignments.assignments.PSObject.Properties[$depId]) {
        $depStatus = $assignments.assignments.$depId.status
    }
    if ($depStatus -ne "completed") {
        Write-Warning "Dependency $depId not completed (status: $depStatus). Cannot claim $TaskId."
        exit 1
    }
}

# Check if already claimed
if ($assignments.assignments.PSObject.Properties[$TaskId]) {
    $current = $assignments.assignments.$TaskId
    if ($current.status -eq "claimed" -or $current.status -eq "running") {
        # Check lease expiry
        $leaseExpires = [DateTime]::Parse($current.leaseExpiresAt)
        if ((Get-Date) -lt $leaseExpires) {
            Write-Warning "Task $TaskId already claimed by $($current.assignedWindow)/$($current.assignedWorker). Lease active until $($current.leaseExpiresAt)"
            exit 1
        }
        Write-Host "Lease expired. Reclaiming $TaskId."
    }
}

# Check window capacity
if (Test-Path $stateFile) {
    $state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($state.windows.PSObject.Properties[$WindowId]) {
        $win = $state.windows.$WindowId
        if ($win.runningTasks.Count -ge $win.capacity) {
            Write-Warning "Window $WindowId at capacity ($($win.capacity)). Cannot claim."
            exit 1
        }
        $win.runningTasks += $TaskId
        $state | ConvertTo-Json -Depth 10 | Set-Content $stateFile -Encoding UTF8
    }
}

# Claim task
$now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"
$leaseExpires = (Get-Date).AddSeconds($LeaseDurationSeconds).ToString("yyyy-MM-ddTHH:mm:ssK")

$assignment = @{
    status = "claimed"
    agentType = if ($subtask.agentType) { $subtask.agentType } else { "worker" }
    assignedWindow = $WindowId
    assignedWorker = $WorkerId
    claimedAt = $now
    leaseExpiresAt = $leaseExpires
    retryCount = if ($assignments.assignments.PSObject.Properties[$TaskId]) { $assignments.assignments.$TaskId.retryCount } else { 0 }
    upstream = if ($subtask.upstreamArtifacts) { $subtask.upstreamArtifacts } else { @() }
}

if (-not $assignments.assignments.PSObject.Properties[$TaskId]) {
    $assignments.assignments | Add-Member -NotePropertyName $TaskId -NotePropertyValue $assignment -Force
} else {
    $assignments.assignments.$TaskId = $assignment
}

$assignments.updatedAt = $now
$assignments | ConvertTo-Json -Depth 10 | Set-Content $assignmentsFile -Encoding UTF8
Write-Host "Task $TaskId claimed by $WindowId/$WorkerId. Lease expires: $leaseExpires"
