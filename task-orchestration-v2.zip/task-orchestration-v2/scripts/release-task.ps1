# release-task.ps1
# 标记任务 completed/failed/blocked，释放执行槽位

param(
    [string]$TaskId,
    [string]$Status = "completed",
    [string]$WindowId = "main",
    [string]$ProjectRoot = $PWD.Path,
    [string]$ReportPath = ""
)

$validStatuses = @("completed", "failed", "blocked")
if ($Status -notin $validStatuses) {
    Write-Error "Invalid status: $Status. Must be one of: $($validStatuses -join ', ')"
    exit 1
}

$workspace = Join-Path $ProjectRoot ".claude\workspace"
$assignmentsFile = Join-Path $workspace "assignments.json"
$stateFile = Join-Path $workspace "state.json"

if (-not (Test-Path $assignmentsFile)) {
    Write-Error "assignments.json not found."
    exit 1
}

$now = Get-Date -Format "yyyy-MM-ddTHH:mm:ssK"

# Update assignments
$assignments = Get-Content $assignmentsFile -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not $assignments.assignments.PSObject.Properties[$TaskId]) {
    Write-Error "Task $TaskId not found in assignments."
    exit 1
}

$assignments.assignments.$TaskId.status = $Status
$assignments.assignments.$TaskId.leaseExpiresAt = $now
$assignments.updatedAt = $now
$assignments | ConvertTo-Json -Depth 10 | Set-Content $assignmentsFile -Encoding UTF8

# Update state - release slot
if (Test-Path $stateFile) {
    $state = Get-Content $stateFile -Raw -Encoding UTF8 | ConvertFrom-Json

    # Remove from window runningTasks
    if ($state.windows.PSObject.Properties[$WindowId]) {
        $state.windows.$WindowId.runningTasks = @($state.windows.$WindowId.runningTasks | Where-Object { $_ -ne $TaskId })
        if ($state.windows.$WindowId.runningTasks.Count -eq 0 -and $WindowId -ne "main") {
            $state.windows.$WindowId.status = "idle"
        }
    }

    # Update subtask status
    if ($state.subtasks.PSObject.Properties[$TaskId]) {
        $state.subtasks.$TaskId.status = $Status
        $state.subtasks.$TaskId.leaseVersion = ($state.subtasks.$TaskId.leaseVersion + 1)
    }

    # Update summary
    $state.summary.running = [Math]::Max(0, ($state.summary.running - 1))
    $state.summary.$Status = ($state.summary.$Status + 1)

    $state.updatedAt = $now
    $state | ConvertTo-Json -Depth 10 | Set-Content $stateFile -Encoding UTF8
}

Write-Host "Task $TaskId released: $Status"
if ($ReportPath) {
    Write-Host "Report: $ReportPath"
}
