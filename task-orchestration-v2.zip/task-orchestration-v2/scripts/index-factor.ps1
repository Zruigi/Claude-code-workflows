# index-factor.ps1
# 将因子记录存储到向量记忆库

param(
    [string]$FactorFile,
    [string]$ProjectRoot = $PWD.Path
)

$enginePath = Join-Path $ProjectRoot ".claude\tools\vector-memory.py"

if (-not (Test-Path $enginePath)) {
    Write-Warning "Vector memory engine not installed."
    exit 1
}

python $enginePath store $FactorFile
