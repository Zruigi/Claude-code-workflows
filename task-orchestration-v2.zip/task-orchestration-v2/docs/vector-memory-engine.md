# Vector Memory Engine

本地向量记忆引擎，为 Agent 提供真正的语义检索能力。

## 1. 架构

```
Agent (任意窗口)
    │
    ├─ 写入因子 → embedding → 存入向量库
    ├─ 检索记忆 → embedding → 查询向量库
    └─ 清理检查 → 查询替代链

┌─────────────────────────────────────────────────┐
│  .claude/memory/                                │
│  ├── factors.jsonl          # 因子原始记录       │
│  ├── factor-graph.json      # 因子关系图         │
│  └── vector-store/          # 向量记忆库         │
│      ├── chroma.sqlite3     # ChromaDB 持久化    │
│      └── embeddings/        # 向量索引           │
└─────────────────────────────────────────────────┘
```

## 2. 向量库选型

| 方案 | 特点 | 适用场景 |
|------|------|----------|
| ChromaDB | Python 原生，轻量，嵌入式 | 本地开发，小中型项目 |
| LanceDB | Rust 底层，文件级，零依赖 | 高性能本地检索 |
| Milvus Lite | 全功能，可升级到集群 | 需要以后扩展 |

**推荐 ChromaDB**：纯 Python，pip install 即可，嵌入式运行，无需服务。

## 3. 核心数据结构

### 因子向量记录

```python
{
    "id": "FACTOR-2026-001",
    "embedding": [0.1, 0.3, ...],  # 1536 维
    "metadata": {
        "cause_type": "refactoring",
        "language": "python",
        "framework": "FastAPI",
        "files_modified": ["src/auth/new_jwt.py"],
        "files_replaced": ["src/auth/old_token.py"],
        "task_id": "task-2026-001",
        "timestamp": "2026-05-05T10:00:00Z"
    },
    "document": "重构 auth 模块：用 JWT 中间件替换旧 token 验证..."
}
```

### 嵌入模型

| 模型 | 维度 | 本地 |
|------|------|------|
| text-embedding-3-small | 1536 | 需 API |
| all-MiniLM-L6-v2 | 384 | ✅ 本地 |
| bge-small-zh | 512 | ✅ 本地(中文) |
| nomic-embed-text | 768 | ✅ 本地 |

**推荐 all-MiniLM-L6-v2** 作为默认，bge-small-zh 处理中文项目。

## 4. 实现脚本

### requirements.txt

```
chromadb>=0.4.0
sentence-transformers>=2.2.0
```

### vector-memory.py (核心引擎)

```python
import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import json
from datetime import datetime
from pathlib import Path

class VectorMemoryEngine:
    def __init__(self, project_root: str):
        self.root = Path(project_root)
        self.store_path = self.root / ".claude" / "memory" / "vector-store"
        self.store_path.mkdir(parents=True, exist_ok=True)
        
        self.client = chromadb.PersistentClient(
            path=str(self.store_path),
            settings=Settings(anonymized_telemetry=False)
        )
        
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        
        self.factors = self.client.get_or_create_collection(
            name="factors",
            metadata={"hnsw:space": "cosine"}
        )
        
        self.calls = self.client.get_or_create_collection(
            name="function_calls",
            metadata={"hnsw:space": "cosine"}
        )

    def store_factor(self, factor: dict) -> str:
        """Store a factor record with embedding"""
        text = self._factor_to_text(factor)
        embedding = self.model.encode(text).tolist()
        
        meta = {
            "cause_type": factor["cause"]["type"],
            "language": factor.get("process", {}).get("language", ""),
            "framework": factor.get("process", {}).get("framework", ""),
            "files_created": json.dumps(factor.get("result", {}).get("artifacts", {}).get("created", [])),
            "files_replaced": json.dumps(factor.get("impact", {}).get("replacesFiles", [])),
            "task_id": factor.get("taskId", ""),
            "timestamp": factor.get("timestamp", ""),
            "agent_type": factor.get("agentType", "")
        }
        
        # Reduce metadata string lengths for ChromaDB
        for k, v in meta.items():
            if isinstance(v, str) and len(v) > 1000:
                meta[k] = v[:1000]
        
        self.factors.add(
            ids=[factor["factorId"]],
            embeddings=[embedding],
            metadatas=[meta],
            documents=[text]
        )
        return factor["factorId"]

    def search_similar(self, query: str, n: int = 5, 
                       filter_type: str = None) -> list:
        """Search for similar factors"""
        embedding = self.model.encode(query).tolist()
        
        where = None
        if filter_type:
            where = {"cause_type": filter_type}
        
        results = self.factors.query(
            query_embeddings=[embedding],
            n_results=n,
            where=where
        )
        
        return [
            {
                "id": id_,
                "distance": dist,
                "metadata": meta,
                "document": doc
            }
            for id_, dist, meta, doc in zip(
                results["ids"][0],
                results["distances"][0],
                results["metadatas"][0],
                results["documents"][0]
            )
        ]

    def find_replacements(self, file_path: str) -> list:
        """Find all factors that reference this file"""
        results = self.factors.get(
            where={"files_replaced": {"$contains": file_path}}
        )
        return results

    def find_code_debt(self) -> list:
        """Find factors where old code was replaced but not deleted"""
        all_results = self.factors.get()
        debt = []
        
        for i, doc in enumerate(all_results["documents"]):
            meta = all_results["metadatas"][i] if all_results["metadatas"] else {}
            replaced = json.loads(meta.get("files_replaced", "[]"))
            created = json.loads(meta.get("files_created", "[]"))
            
            if replaced:
                for rf in replaced:
                    debt.append({
                        "factor_id": all_results["ids"][i],
                        "replaced_file": rf,
                        "new_file": created,
                        "status": "pending_cleanup"
                    })
        
        return debt

    def _factor_to_text(self, factor: dict) -> str:
        """Convert factor record to searchable text"""
        cause = factor.get("cause", {})
        process = factor.get("process", {})
        impact = factor.get("impact", {})
        
        parts = [
            f"Cause: {cause.get('type', '')} - {cause.get('description', '')}",
            f"Language: {process.get('language', '')}",
            f"Framework: {process.get('framework', '')}",
            f"Pattern: {process.get('pattern', '')}",
            f"Files created: {', '.join(process.get('filesCreated', []))}",
            f"Files replaced: {', '.join(impact.get('replacesFiles', []))}",
            f"Affected callers: {', '.join(impact.get('affectedCallers', []))}",
            f"Migration: {'yes' if impact.get('migrationRequired') else 'no'}"
        ]
        return "; ".join(parts)

# CLI interface for use in scripts
if __name__ == "__main__":
    import sys
    engine = VectorMemoryEngine(Path.cwd())
    
    cmd = sys.argv[1] if len(sys.argv) > 1 else "help"
    
    if cmd == "search":
        query = " ".join(sys.argv[2:])
        results = engine.search_similar(query, n=5)
        for r in results:
            print(f"  {r['id']} ({r['distance']:.3f}): {r['document'][:100]}")
    
    elif cmd == "debt":
        debt = engine.find_code_debt()
        for d in debt:
            print(f"  ⚠ {d['replaced_file']} → replaced by {d['new_file']}, not deleted")
    
    elif cmd == "related":
        file_path = sys.argv[2]
        results = engine.find_replacements(file_path)
        print(f"  Factors referencing {file_path}:")
        for r in results.get("ids", []):
            print(f"    - {r}")
    
    elif cmd == "store":
        factor_json = sys.argv[2]
        with open(factor_json) as f:
            factor = json.load(f)
        fid = engine.store_factor(factor)
        print(f"  Stored: {fid}")
    
    elif cmd == "help":
        print("Usage: python vector-memory.py <command>")
        print("  search <query>       Search similar factors")
        print("  debt                 Find code debt")
        print("  related <file_path> Find related factors")
        print("  store <factor.json>  Store a factor record")
```

## 5. PowerShell 脚本集成

### scripts/index-factor.ps1

```powershell
param(
    [string]$FactorFile,
    [string]$ProjectRoot = $PWD.Path
)

$enginePath = Join-Path $ProjectRoot ".claude\tools\vector-memory.py"
if (-not (Test-Path $enginePath)) {
    Write-Error "vector-memory.py not found. Install first."
    exit 1
}

python $enginePath store $FactorFile
```

### scripts/search-similar.ps1

```powershell
param(
    [string]$Query,
    [string]$ProjectRoot = $PWD.Path
)

$enginePath = Join-Path $ProjectRoot ".claude\tools\vector-memory.py"
python $enginePath search $Query
```

### scripts/debt-check.ps1

```powershell
param(
    [string]$ProjectRoot = $PWD.Path
)

$enginePath = Join-Path $ProjectRoot ".claude\tools\vector-memory.py"

Write-Host "=== Code Debt Report ==="
python $enginePath debt

Write-Host ""
Write-Host "=== Deprecation Notices ==="
$factorsFile = Join-Path $ProjectRoot ".claude\memory\decisions\factors.jsonl"
if (Test-Path $factorsFile) {
    Get-Content $factorsFile | ForEach-Object {
        $factor = $_ | ConvertFrom-Json
        if ($factor.impact.deprecationNotice) {
            $deadline = $factor.impact.cleanupDeadline
            $now = Get-Date
            $daysLeft = ([DateTime]$deadline - $now).Days
            $flag = if ($daysLeft -lt 0) { "OVERDUE" } else { "${daysLeft}d left" }
            Write-Host "  [$flag] $($factor.factorId): $($factor.impact.deprecationNotice)"
        }
    }
}
```

## 6. Agent 如何使用

### Agent 启动时

```markdown
Agent 启动后，在读取项目记忆时：
1. 检索相关因子（自动执行）
   → python .claude/tools/vector-memory.py search "当前任务描述"
   
2. 检查代码债务（自动执行）  
   → python .claude/tools/vector-memory.py debt
   
3. 如果发现类似历史任务 → 查看其 factor record
4. 如果发现代码债务 → 在实现中优先清理
```

### Agent 写入时

```powershell
# 任务完成后，写入因子记录
python .claude/tools/vector-memory.py store .claude/workspace/reports/SUB-001-factor.json
```

## 7. 集成到项目初始化

```powershell
# init-project-memory.ps1 新增:
pip install chromadb sentence-transformers -q
Copy-Item $templateDir/vector-memory.py .claude/tools/
Write-Host "Vector memory engine installed."
```

## 8. 与 Agent prompt 集成

Worker prompt 增加：

```markdown
### Step -1: 检索历史记忆
在开始工作前：
1. 检索向量记忆库中与当前任务相似的因子
   → py vector-memory.py search "当前任务描述"
2. 如果发现相似因子 → 参考其实现
3. 如果发现未清理的旧代码 → 优先清理
```

## 9. 推荐落地顺序

| 阶段 | 内容 | 工作量 |
|------|------|--------|
| Phase 1 | 安装 ChromaDB + 运行 vector-memory.py | 5 分钟 |
| Phase 2 | Agent prompt 集成检索步骤 | 10 分钟 |
| Phase 3 | 自动 debt-check 挂到 reviewer | 10 分钟 |
| Phase 4 | 相似检索 → 自动建议替代关系 | 后续迭代 |
