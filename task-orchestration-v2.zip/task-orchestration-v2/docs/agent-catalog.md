# Agent Catalog v2.1

统一角色目录，定义所有可调度 Agent 的类型、触发条件、输入输出和职责范围。

## 1. Agent 总览

| Agent | 分类 | 适用 Phase | 触发条件 |
|-------|------|------------|----------|
| orchestrator | orchestrator | orchestration | 接收复杂任务 |
| worker | worker | implementation | 被分配任务 |
| frontend-dev | specialized | feature-analysis, implementation | 前端/UI/组件 |
| backend-dev | specialized | feature-analysis, implementation | 后端/API/接口 |
| bug-fixer | specialized | bug-fix | bug/修复/错误 |
| db-admin | specialized | implementation | 数据库/SQL/迁移 |
| security-expert | specialized | review | 安全/漏洞/渗透 |
| reviewer | reviewer | review | 所有 Worker 完成 |
| archiver | archiver | archive | 审查通过 |

## 2. 各 Agent 详细定义

### frontend-dev
| 属性 | 值 |
|------|-----|
| category | specialized |
| promptFile | templates/project-agents/frontend-dev.md |
| triggers | 前端, UI, 组件, react, vue, 样式, css, 页面 |
| inputs | project-spec, frontend-architecture |
| outputs | feature-analysis, frontend-report |
| phases | feature-analysis, implementation |

### backend-dev
| 属性 | 值 |
|------|-----|
| category | specialized |
| promptFile | templates/project-agents/backend-dev.md |
| triggers | 后端, API, 接口, node, python, go |
| inputs | project-spec, backend-architecture, feature-analysis(前端) |
| outputs | api-contract, backend-report |
| phases | feature-analysis, implementation |

### bug-fixer
| 属性 | 值 |
|------|-----|
| category | specialized |
| promptFile | templates/project-agents/bug-fixer.md |
| triggers | bug, 修复, 错误, 崩溃, 异常, 报错 |
| inputs | project-spec, error-logs, test-reports |
| outputs | bug-fix-report |
| phases | bug-fix |

### db-admin
| 属性 | 值 |
|------|-----|
| category | specialized |
| promptFile | templates/project-agents/db-admin.md |
| triggers | 数据库, SQL, 迁移, schema, 索引 |
| inputs | project-spec, database-architecture |
| outputs | migration-report, schema-actual |
| phases | implementation |

### security-expert
| 属性 | 值 |
|------|-----|
| category | specialized |
| promptFile | templates/project-agents/security-expert.md |
| triggers | 安全, 漏洞, 渗透, 加密, 认证 |
| inputs | project-spec, code-diff |
| outputs | security-review-report |
| phases | review |

## 3. 协作链路

### 前后端协作（主链路）
```
frontend-dev (生成功能论证)
    ↓
backend-dev (根据论证设计 API 契约)
    ↓
frontend-dev + backend-dev (并行实现)
    ↓
reviewer (对齐检查)
```

### Bug 修复链路
```
bug-fixer (复现 → 定位 → 修复 → 验证)
    ↓
reviewer (回归审查)
```

### 数据库链路
```
db-admin (迁移/schema 分析)
    ↓
archiver (更新数据库架构文档)
```

### 安全链路
```
security-expert (安全审查)
    ↓
reviewer (综合审查)
```

## 4. 标准产物

| 产物 | 路径 | 产出者 |
|------|------|--------|
| 功能论证报告 | .claude/memory/decisions/[功能名]-功能论证.md | frontend-dev |
| API 契约 | .claude/memory/decisions/[功能名]-API契约.md | backend-dev |
| 对齐检查 | .claude/workspace/contracts/[功能名]-alignment.json | reviewer |
| 任务报告 | .claude/workspace/reports/SUB-XXX.json | 各 Worker |
| 安全报告 | .claude/workspace/reports/SECURITY-XXX.json | security-expert |