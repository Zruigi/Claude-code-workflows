# Cross-Window Execution v2.1

跨窗口自动唤起与并行执行机制。

## 1. 总览

```
Orchestrator
  ├─ 判断当前并行可用槽位
  ├─ 若本窗口仍可承载 → 本窗口继续执行
  ├─ 若超阈值且有空闲窗口 → 复用空闲窗口
  ├─ 若超阈值且无空闲窗口 → 启动新窗口
  ├─ 新窗口完成注册
  └─ assignments.json 分配可执行子任务
```

## 2. 窗口生命周期

```
starting → idle ⇄ busy → idle → offline
                ↘ stale → offline
```

### 状态定义

| 状态 | 含义 |
|------|------|
| starting | 窗口启动中，未完成注册 |
| idle | 注册完成，等待任务分配 |
| busy | 已分配任务，执行中 |
| stale | 心跳超时 1 个间隔，等待恢复 |
| offline | 心跳超时 3 个间隔，已失联 |

## 3. 窗口池配置

```json
{
  "windowPool": {
    "maxWindows": 4,
    "mainCapacity": 4,
    "subCapacity": 2,
    "windowIds": ["main", "window-2", "window-3", "window-4"]
  }
}
```

### 容量规则

| 窗口 | 容量 | 角色 |
|------|------|------|
| main | 4 个执行槽位 | orchestrator + worker |
| window-2 | 2 个执行槽位 | worker-host |
| window-3 | 2 个执行槽位 | worker-host |
| window-4 | 2 个执行槽位 | worker-host |

**最大执行槽位总数**: 10

## 4. 唤起条件

不再使用简单的"并行数 > 4"，改用容量阈值：

```text
如果 可用执行槽位 < 待调度任务数 且 当前窗口数 < maxWindows：
    新开窗口
否则：
    等待空闲槽位
```

### 调度优先级

1. 优先用 `main` 窗口空闲槽位
2. 其次用 `idle` 窗口
3. 再次用 `busy` 但未满载窗口
4. 最后才新开窗口

## 5. 窗口注册协议

新窗口启动后必须完成三件事：

1. 读取 `.claude/workspace/state.json`
2. 申请 `windowId`（调用 `scripts/register-window.ps1`）
3. 写入注册信息

### 注册结构

```json
{
  "windowId": "window-2",
  "role": "worker-host",
  "status": "idle",
  "pid": 12345,
  "startedAt": "2026-05-03T07:13:00Z",
  "lastHeartbeatAt": "2026-05-03T07:13:00Z",
  "cwd": "C:/project",
  "capacity": 2,
  "runningTasks": []
}
```

### 注册超时
- 窗口启动后 60 秒内未写入注册信息 → 视为失败
- 不分配任务给该窗口
- 标记为 `offline`

## 6. 失败恢复

### 启动失败
```
1. 记录到 logs/orchestrator.log
2. 将相关任务重新回退到 pending
3. 标记 spawnAttempts + 1
4. 超过 3 次 → 降级为单窗口执行
```

### 启动后未注册
```
1. 60 秒内未注册 → 视为失败
2. 不分配任务给该窗口
3. 标记状态为 offline
```

### 窗口失联
```
1. lastHeartbeatAt 超过 30s 未刷新 → stale
2. 超过 90s → offline
3. 回收其 runningTasks 到 pending
4. 记录到 orchestrator 日志
```

## 7. 脚本职责

| 脚本 | 职责 |
|------|------|
| spawn-window.ps1 | 计算是否需要新窗口 + 启动 |
| register-window.ps1 | 分配 windowId + 注册元数据 |
| release-window.ps1 | 清空任务 + 标记 idle/offline |
| window-health-check.ps1 | 扫描心跳过期窗口 + 回收任务 |

## 8. 配置项

```json
{
  "crossWindowExecution": {
    "enabled": true,
    "maxWindows": 4,
    "mainCapacity": 4,
    "subCapacity": 2,
    "autoSpawnThreshold": 4,
    "startupTimeoutMs": 60000,
    "heartbeatIntervalMs": 30000,
    "heartbeatTimeoutMs": 90000,
    "maxSpawnAttempts": 3,
    "spawnMethod": "powershell -File scripts/spawn-window.ps1"
  }
}
```