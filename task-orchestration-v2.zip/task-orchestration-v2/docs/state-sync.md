# State Sync Protocol v2.1

状态同步协议，定义运行时文件边界、写入规则、心跳机制。

## 1. 文件职责划分

### framework.json
**静态框架定义，生成后尽量只读或低频更新**

```json
{
  "version": "2.1",
  "taskName": "string",
  "complexityScore": 8,
  "subtasks": [
    {
      "id": "SUB-001",
      "name": "string",
      "agentType": "frontend-dev",
      "dependencies": [],
      "acceptanceCriteria": ["criteria1"],
      "featureRequirement": "workflow-editor",
      "coordinationInputs": ["frontend-architecture"],
      "upstreamArtifacts": [],
      "downstreamConsumers": ["SUB-002"]
    }
  ],
  "dependencyGraph": { "SUB-001": [] },
  "metadata": {
    "decompositionDepth": 2,
    "parallelizable": true
  }
}
```

**规则**：
- 由 Orchestrator 初始化
- 后续只读或附加 feature analysis 结果
- 不包含运行时状态

### assignments.json
**调度账本，记录任务到窗口/worker 的映射**

```json
{
  "version": "2.1",
  "taskId": "task-2026-001",
  "updatedAt": "2026-05-03T07:20:00Z",
  "assignments": {
    "SUB-001": {
      "status": "claimed",
      "agentType": "frontend-dev",
      "assignedWindow": "main",
      "assignedWorker": "worker-1",
      "claimedAt": "2026-05-03T07:14:00Z",
      "leaseExpiresAt": "2026-05-03T07:15:30Z",
      "retryCount": 0
    }
  }
}
```

**规则**：
- Worker 可写自己任务的 lease 心跳字段
- 主控汇总维护

### state.json
**活体运行时状态**

```json
{
  "version": "2.1",
  "taskId": "task-2026-001",
  "status": "running",
  "phase": "worker",
  "startedAt": "2026-05-03T07:13:00Z",
  "updatedAt": "2026-05-03T07:20:00Z",
  "heartbeatIntervalMs": 30000,
  "heartbeatTimeoutMs": 90000,
  "summary": {
    "totalSubtasks": 8,
    "pending": 2,
    "running": 3,
    "completed": 3,
    "failed": 0,
    "blocked": 0
  },
  "windows": {
    "main": {
      "status": "busy",
      "pid": 1001,
      "role": "orchestrator",
      "capacity": 4,
      "runningTasks": ["SUB-001", "SUB-002"],
      "lastHeartbeatAt": "2026-05-03T07:19:55Z"
    }
  },
  "subtasks": {
    "SUB-001": {
      "status": "running",
      "assignedWindow": "main",
      "assignedWorker": "worker-1",
      "lastHeartbeatAt": "2026-05-03T07:19:54Z",
      "leaseVersion": 3
    }
  }
}
```

**规则**：
- Worker 不直接手工全量改写 `state.json`
- 运行时允许通过受控脚本更新 `state.json`
- `heartbeat.ps1`、`claim-task.ps1`、`release-task.ps1` 只更新自己负责的局部字段
- `reconcile-state.ps1` 负责周期性汇总、修正 summary、清理 stale/offline 状态
- 若要严格单写者模式，可在后续将 heartbeat / claim / release 改成事件日志追加模式

## 2. 并发写协议

### 当前实现：受控脚本写入 + reconcile 汇总

```text
Orchestrator / Coordinator
  ├─ 初始化 framework / assignments / state
  ├─ 轮询 reports/*.json
  ├─ 轮询 assignments.json
  ├─ 运行 reconcile-state.ps1 统一汇总
  └─ 负责最终 summary / stale / offline 收口

Worker / Window
  ├─ 写 reports/SUB-XXX.json
  ├─ 写 assignments.json 中自己的 lease
  ├─ 通过 heartbeat.ps1 更新心跳局部字段
  ├─ 通过 claim-task.ps1 / release-task.ps1 更新任务局部字段
  └─ 不手工直接覆盖整个 state.json
```

### 写保护规则

| 文件 | 写者 | 写的频率 |
|------|------|----------|
| state.json | 受控脚本 + reconcile 汇总 | 心跳/认领/释放/每 15 秒汇总 |
| assignments.json | Coordinator 主，Worker 辅 | 认领/完成时 |
| reports/*.json | 对应 Worker | 任务完成时 |
| logs/*.jsonl | 所有窗口 append | 每事件 |
| framework.json | Orchestrator | 任务开始时 + 低频追加 |

## 3. 心跳策略

### 主窗口 (Orchestrator)
- 每 **15 秒** 轮询运行时文件
- 每 **30 秒** 刷新自身心跳到 state.json
- 每轮或定时运行 `reconcile-state.ps1`

### Worker 窗口
- 每 **30 秒** 通过 `heartbeat.ps1` 刷新窗口级心跳
- 若有任务，同步刷新任务级心跳

### 附属窗口
- 每 **30 秒** 通过 `heartbeat.ps1` 刷新心跳
- 通过受控脚本更新，不手工修改 state.json

### 失联判定

| 阶段 | 条件 | 动作 |
|------|------|------|
| stale | 超过 1 个间隔 (30s) 未更新 | 标记 stale，发出警告 |
| offline | 超过 3 个间隔 (90s) 未更新 | 标记 offline，回收任务 lease |
| dead | 超过 6 个间隔 (180s) 未更新 | 标记 dead，清理窗口注册 |

## 4. 事件日志 (可选升级)

```jsonl
{"event":"window_registered","windowId":"window-2","timestamp":"2026-05-03T07:13:00Z"}
{"event":"heartbeat","windowId":"main","timestamp":"2026-05-03T07:13:30Z"}
{"event":"task_claimed","taskId":"SUB-001","windowId":"main","workerId":"worker-1","timestamp":"2026-05-03T07:14:00Z"}
{"event":"task_completed","taskId":"SUB-001","windowId":"main","workerId":"worker-1","timestamp":"2026-05-03T07:20:00Z"}
{"event":"task_failed","taskId":"SUB-002","windowId":"main","workerId":"worker-2","reason":"test failure","timestamp":"2026-05-03T07:21:00Z"}
```

## 5. 相关脚本

| 脚本 | 职责 |
|------|------|
| init-workspace-state.ps1 | 初始化所有运行时文件 |
| heartbeat.ps1 | 刷新心跳局部字段 |
| claim-task.ps1 | 认领 pending 任务 |
| release-task.ps1 | 标记完成/失败/阻塞 |
| reconcile-state.ps1 | 汇总状态、清理过期 lease |
| window-health-check.ps1 | 扫描心跳过期窗口 |
