# Specialized Agent Coordination v2.1

统一协作协议，确保 specialized agents 之间产出协同一致。

## 1. 协作链路总览

```
Orchestrator
  ├─ 读取 agents.manifest.json 确定需要哪些 Agent
  ├─ 触发 frontend-dev 功能论证
  ├─ 等待功能论证产出
  ├─ 触发 backend-dev API 契约
  ├─ 等待 API 契约产出
  ├─ 触发 reviewer 对齐检查
  └─ 确认对齐后并行实现
```

## 2. 三种标准产物

### 2.1 功能论证
- **产出者**: frontend-dev
- **路径**: `.claude/memory/decisions/[功能名]-功能论证.md`
- **内容**: 功能清单 + 参考案例 + API 对照表

### 2.2 API 契约
- **产出者**: backend-dev
- **输入依赖**: 功能论证（frontend-dev 产出）
- **路径**: `.claude/memory/decisions/[功能名]-API契约.md`
- **内容**: API 接口列表 + 数据模型 + 错误码

### 2.3 对齐检查
- **产出者**: reviewer（或 orchestrator）
- **输入依赖**: 功能论证 + API 契约
- **路径**: `.claude/workspace/contracts/[功能名]-alignment.json`
- **格式**:
```json
{
  "featureName": "workflow-editor",
  "frontendOperations": 12,
  "mappedApis": 12,
  "missingApis": [],
  "mismatchedFields": [],
  "status": "aligned"
}
```

## 3. Agent 间契约

### frontend-dev → backend-dev

**frontend-dev 必须提供**:
1. 功能清单文件
2. 每个功能需要的 API 操作
3. 期望的请求/响应格式

**backend-dev 必须提供**:
1. API 契约文件
2. 每个前端操作对应的 API 端点
3. 统一的错误码

### backend-dev → frontend-dev

**backend-dev 完成后**:
1. frontend-dev 验证 API 是否足够
2. 确认响应格式与前端预期一致
3. 实现过程中发现不足时反馈

## 4. 协作规则

### 规则 1: 依赖必须显式声明
```
每个子任务在 framework.json 中声明:
- upstreamArtifacts: 需要的上游产出
- downstreamConsumers: 依赖此产出的下游任务
```

### 规则 2: 上游优先执行
```
feature-analysis phase 任务优先于 implementation phase 任务
upstreamArtifacts 非空的任务必须等待上游完成
```

### 规则 3: 产出文件必须自描述
```
每个文件第一行必须标注:
- 产出者 agentType
- 依赖的上游文件
```

### 规则 4: 对齐检查必须通过才能实现
```
alignment.status != "aligned" → 不能进入 implementation phase
```

## 5. 错误码统一

| 错误码 | 含义 | 前端处理 | 后端响应 |
|--------|------|----------|----------|
| 200 | 成功 | 正常处理 | `{ code: 200, data: {} }` |
| 201 | 创建成功 | 跳转/提示 | `{ code: 201, data: { id: N } }` |
| 400 | 参数错误 | 表单提示 | `{ code: 400, errors: [] }` |
| 401 | 未登录 | 跳转登录 | `{ code: 401, message: "" }` |
| 403 | 无权限 | 提示权限不足 | `{ code: 403 }` |
| 404 | 不存在 | 提示不存在 | `{ code: 404 }` |
| 409 | 业务冲突 | 提示原因 | `{ code: 409, message: "" }` |
| 500 | 服务器错误 | 稍后重试 | `{ code: 500 }` |

## 6. Specialized Agent 特有契约

### bug-fixer
- 必须有复现证据（日志/截图）
- 必须有回归测试
- 禁止猜测修复

### db-admin
- 必须有迁移脚本
- 必须有回滚脚本
- 必须有验证步骤

### security-expert
- 必须有风险等级
- 必须有 CWE/OWASP 引用
- 必须有修复建议

## 7. 异常处理

| 情况 | 处理 |
|------|------|
| 上游超时 | 下游标记 blocked |
| 产物不完整 | reviewer 标记 fail，返回重做 |
| 对齐失败 | missingApis 记录差异，通知相关 Agent |