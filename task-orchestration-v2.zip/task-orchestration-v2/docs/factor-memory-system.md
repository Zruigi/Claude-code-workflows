# Factor Memory System v1.0

因子化记忆系统，解决 Agent 代码膨胀问题（只增不删）。

## 1. 问题模型

### 当前 Agent 行为

```
新需求
  └→ 写新模块 func_new()
  └→ 保留旧模块 func_old()
  └→ 写适配器 adapter(func_new, func_old)
  └→ 完事

结果：
  func_old()  ← 历史决策的痕迹 仍在
  func_new()  ← 新的实现
  adapter()   ← 又一层包裹
  → 代码量翻倍，调用链翻倍，没删任何东西
```

### 根因

Agent 拥有的是"添加能力"（写、修改、创建），但没有"因子化意识"——
它不知道新模块与旧模块之间有"替代关系"，
也不知道替代发生后必须标记旧模块为"可清理"。

## 2. 核心设计

### 因子分解模型

```
每个任务产出必须拆分为 4 个因子维度的记录：

┌─────────────────────────────────────────────────────┐
│  起因 (Cause)      流程 (Process)                    │
│  为什么要做         怎么做的                          │
│  · 需求驱动         · 使用语言/框架                  │
│  · Bug 触发         · 实现方式/模式                  │
│  · 重构目标         · 测试情况                       │
├─────────────────────────────────────────────────────┤
│  结果 (Result)      影响 (Impact)                    │
│  产出什么           改变了什么                        │
│  · 新增文件         · 替代了哪些旧代码 (关键)        │
│  · 修改文件         · 影响了哪些调用方               │
│  · 删除文件         · 是否需要迁移数据               │
└─────────────────────────────────────────────────────┘
```

### 因子条目格式

```json
{
  "factorId": "FACTOR-2026-001",
  "taskId": "task-2026-001",
  "timestamp": "2026-05-05T10:00:00Z",
  "agentType": "backend-dev",

  "cause": {
    "type": "refactoring | bugfix | feature | optimization",
    "description": "client_id 被注销，需要切换到新的鉴权机制",
    "trigger": "安全审计发现旧 token 机制不满足合规要求",
    "priority": "P1"
  },

  "process": {
    "language": "python",
    "framework": "FastAPI",
    "pattern": "middleware-based-auth",
    "filesCreated": ["src/auth/new_jwt.py"],
    "filesModified": ["src/main.py"],
    "filesDeleted": [],
    "testCoverage": 85
  },

  "result": {
    "artifacts": {
      "created": ["src/auth/new_jwt.py", "tests/test_new_jwt.py"],
      "modified": ["src/main.py"],
      "deleted": []
    },
    "acceptancePassed": true,
    "qualityScore": 8
  },

  "impact": {
    "replacesFactors": [],
    "replacesFiles": ["src/auth/old_token.py"],
    "replacesFunctions": ["validate_legacy_token()"],
    "affectedCallers": ["src/api/users.py", "src/api/products.py"],
    "migrationRequired": true,
    "migrationScript": "scripts/migrate_auth.py",
    "deprecationNotice": "old_token.py 将在 2 个版本后移除"
  }
}
```

## 3. 替代检测与删除协议

### 替代关系声明

当 Agent 产出新代码时，**必须**填写 impact 字段：

```
新增代码 → 检查是否存在旧实现 → 如果存在 → 声明替代关系
                                            ↓
                            标记 replacesFactors / replacesFiles
                                            ↓
                            编写迁移/适配脚本
                                            ↓
                            设置 deprecationNotice
```

### 删除协议

```
deprecationNotice 发布
    ↓
下一个版本: 旧代码标记为 @deprecated
    ↓
再下一个版本: 删除旧代码 + 适配器
    ↓
factor 图谱中记录: FACTOR-OLD → REPLACED_BY → FACTOR-NEW
```

### Agent 强制约束

```
Agent 每次编写新代码前，必须回答三个问题：
1. 这个新代码是否替代了某个旧实现？
   → 如果是：填写 impact.replacesFiles
2. 旧实现是否还有调用方？
   → 如果是：先迁移调用方，再标记旧代码
3. 删除旧代码的时机是什么？
   → 明确 deprecationNotice
```

## 4. 因子检索与匹配

### 相似度匹配

当新任务到达时，检索历史因子匹配相似案例：

```
新任务因子分解
    ↓
查询历史因子图
    ↓
按相似度排序

相似度 = 
  0.4 × cause 相似度 (同类型、同触发)
+ 0.3 × process 相似度 (同语言、同框架)
+ 0.3 × impact 相似度 (同文件、同调用方)
```

### 检索用途

| 场景 | 检索目的 |
|------|----------|
| 新任务 | 找到类似历史任务，参考其实现 |
| 重构 | 找到所有替代链条，定位可清理代码 |
| Bug 修复 | 找到相关因子，缩小定位范围 |
| 影响评估 | 找到所有受影响调用方 |

## 5. 因子图谱结构

```
FACTOR-001 (初始实现)
  └→ FACTOR-003 (Bug 修复)
  └→ FACTOR-005 (重构替代)
       └→ replaces: FACTOR-001
       └→ replaces: FACTOR-003
       └→ FACTOR-006 (数据迁移)
            └→ depends_on: FACTOR-005

查询"未清理因子":
  → 找到所有被 replaces 但未 deleted 的 factor
  → 生成清理建议列表
```

## 6. 集成到工作流

### Agent 层面

```
frontend-dev / backend-dev / bug-fixer
    │
    ├→ 任务开始前：检索历史相关 factor
    ├→ 任务执行中：声明替代关系
    ├→ 任务完成后：写入 factor record
    └→ 归档时：更新 factor graph
```

### Skill 层面

```
/debt-check
  → 扫描 factor 图谱
  → 列出所有"被替代但未清理"的代码
  → 生成清理建议

/factor-search <关键词>
  → 检索因子图谱
  → 返回相关历史因子
  → 展示替代链条

/deprecate <旧模块>
  → 标记旧模块为可清理
  → 生成迁移脚本
  → 设置清理 deadline
```

### 配置新增

```json
{
  "factorMemory": {
    "enabled": true,
    "storePath": ".claude/memory/decisions/factors.jsonl",
    "graphPath": ".claude/memory/decisions/factor-graph.json",
    "maxFactorsPerTask": 10,
    "similarityThreshold": 0.5,
    "autoCleanupCheck": true,
    "deprecationPolicy": {
      "maxDeprecatedVersions": 2,
      "autoFlagStale": true
    }
  }
}
```

## 7. 因子压缩与归档

### 压缩策略

当因子数量 > 阈值时，合并相似因子：

```
FACTOR-002, FACTOR-004, FACTOR-007
  → 三个因子都是"同一个 auth 模块的 bug 修复"
  → 合并为 FACTOR-BUNDLE-001
  → 保留关键信息，合并摘要
```

### 归档规则

```
已完成任务的因子 → 保留 90 天
被替代的因子 → 标记 ARCHIVED，移到归档
关键因子 → 永久保留（标记 PINNED）
```

## 8. 实现路径

### Phase 1: 因子记录
- 扩展 task-report.json 增加 factor 字段
- Agent prompt 增加因子分解要求
- 因子写入 `.claude/memory/decisions/factors.jsonl`

### Phase 2: 替代检测
- Agent prompt 增加替代检测问题
- Reviewer 检查 impact.replacesFiles 是否填写
- 生成 deprecation notice

### Phase 3: 清理检查
- `/debt-check` 命令扫描未清理代码
- 自动生成清理 PR
- Agent 每次运行检查是否有 pending deprecation

### Phase 4: 检索匹配
- 新任务相似因子检索
- 影响范围自动分析
- 代码变更影响图谱
