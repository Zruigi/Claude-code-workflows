# 项目技术规范

生成时间: {{timestamp}}
版本: 1.0

---

## 1. 项目概述

| 属性 | 值 |
|------|-----|
| 项目名称 | {{project_name}} |
| 本地路径 | {{local_path}} |
| Git 仓库 | {{git_repo}} |
| 主分支 | {{main_branch}} |

---

## 2. 模块结构

| 模块名称 | 职责描述 | 入口文件 | 最后修改 |
|----------|----------|----------|----------|
| {{module_name}} | {{responsibility}} | {{entry_file}} | {{last_modified}} |

---

## 3. 技术栈

### 3.1 核心技术

| 类别 | 技术 | 版本 | 用途 |
|------|------|------|------|
| 语言 | {{language}} | {{version}} | {{purpose}} |
| 框架 | {{framework}} | {{version}} | {{purpose}} |

### 3.2 开发工具

| 工具 | 用途 |
|------|------|
| {{tool}} | {{purpose}} |

---

## 4. 质量基线

| 维度 | 当前值 | 阈值 | 状态 |
|------|--------|------|------|
| 代码质量 | {{quality_score}} | ≥ 7 | ✅/❌ |
| 安全性 | {{security_score}} | ≥ 8 | ✅/❌ |
| 性能 | {{performance_score}} | ≥ 6 | ✅/❌ |

---

## 5. 约束规则

### 5.1 必须遵守

1. **任务分解规则**
   - 最大分解深度: 3 层
   - 最大子任务数: 8 个
   - 单任务最小粒度: 1 文件/1 函数

2. **质量门禁**
   - 代码质量分 ≥ 7/10
   - 安全性分 ≥ 8/10
   - 所有验收标准必须通过

3. **隔离规则**
   - Worker 使用 worktree 隔离
   - 完成后清理临时文件
   - 不共享内存上下文

### 5.2 最佳实践

- {{best_practice_1}}
- {{best_practice_2}}

---

## 6. 变更历史

| 日期 | 任务 | 变更文件数 | 审查分 | 状态 |
|------|------|------------|--------|------|
| {{date}} | {{task_name}} | {{files_count}} | {{score}} | {{status}} |

---

## 7. 附录

### 7.1 工作流命令

```bash
# 启动任务编排
/orchestrate <任务描述>

# 查看工作区状态
cat .claude/workspace/state.json

# 手动触发审查（需要 PR 号）
/review <PR号>
```

### 7.2 文件路径

| 文件类型 | 路径 |
|----------|------|
| 任务框架 | `.claude/workspace/framework.json` |
| 任务报告 | `.claude/workspace/reports/*.json` |
| 审查报告 | `.claude/workspace/review.json` |
| 项目规范 | `.claude/rules/project-spec.md` |
