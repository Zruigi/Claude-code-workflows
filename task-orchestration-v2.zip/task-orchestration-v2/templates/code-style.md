# 代码风格指南模板

## 命名规范

### 文件
- Vue/React 组件: PascalCase (`UserCard.vue`)
- 工具函数: camelCase (`formatDate.ts`)
- 样式: kebab-case (`user-card.module.scss`)

### 变量
- 常量: UPPER_SNAKE (`MAX_RETRY_COUNT`)
- 函数/变量: camelCase (`fetchUserData`)
- 类/接口: PascalCase (`UserService`)

## 目录规范

### 前端
- 公共组件 → `src/components/common/`
- 业务组件 → `src/components/business/`
- 页面私有组件 → `src/pages/xxx/components/`

### 后端
- 路由 → `src/modules/xxx/xxx.controller.ts`
- 服务 → `src/modules/xxx/xxx.service.ts`
- 模型 → `src/database/entities/`

## 注释规范

1. 优先使用语义化的函数/变量名替代注释
2. 只在 WHY 不明确时才写注释
3. 不使用 TODO（用 Factor ID 替代）

## 提交规范

1. 一个提交只做一件事
2. 提交信息: `type(scope): description`
3. Type: feat/fix/refactor/docs/test/chore
