# Task Orchestration Workflow v2.1

多 Agent 任务编排系统，支持架构论证、功能论证、智能路由、跨窗口并行、状态同步与 specialized agent 协作。

## 核心改进 (v2 → v2.1)

| 改进点 | v2 | v2.1 |
|--------|-----|------|
| 功能论证 | 无 | 前后端协同论证，防止遗漏 |
| 前端设计要素 | 无 | 基础功能清单 + 参考案例 |
| 后端 API 契约 | 无 | 前后端接口对齐 |
| 架构论证 | 前端/后端/数据库 | 保持 |
| 跨窗口执行 | 并行数触发 | 窗口池 + 容量模型 + 注册协议 |
| 状态同步 | 简单心跳 | framework / assignments / state 三分法 |
| Specialized 协作 | 分散定义 | manifest + 协作文档 + 对齐产物 |

## 快速开始

```text
/orchestrate <任务描述>
```

## 完整流程

```text
PHASE 0: 前置检查
  • 检查任务复杂度
  • 简单任务直接执行，跳过编排

PHASE 1: Orchestrator
  • 复杂度评估
  • 架构论证（新项目/新模块）
  • 功能论证（新功能）
  • 任务分解

PHASE 1.5: 功能论证
  • frontend-dev 生成功能清单
  • backend-dev 生成 API 契约
  • reviewer / orchestrator 产出 alignment.json

PHASE 2: Worker Pool
  • 并行执行子任务
  • 智能派遣：frontend-dev / backend-dev / bug-fixer / db-admin / security-expert
  • 跨窗口并行（容量模型 + 窗口池）

PHASE 3: Reviewer
  • 审查验证
  • 功能链完整性检查
  • 前后端一致性检查
  • specialized 输出契约检查

PHASE 4: Archiver
  • 归档规范
  • 更新项目记忆
```

## 功能论证阶段（核心新增）

### 解决的问题

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 前端遗漏基础功能 | 凭想象实现 | 功能清单逐项检查 |
| 前后端不一致 | 各自为政 | 接口契约 + 对齐检查 |
| 参考案例缺失 | 闭门造车 | 自动搜索 GitHub 参考 |

### 前端功能要素清单

每个前端任务必须考虑：

| 类别 | 必需功能 |
|------|----------|
| CRUD | 增/删/改/查 |
| 选择 | 单选/多选 |
| 删除 | 删除确认弹窗 |
| 撤销 | 撤销/重做 |
| 保存 | 自动保存/手动保存 |
| 加载 | 骨架屏 / Loading |
| 空状态 | 空数据展示 |
| 错误 | 错误提示 / 重试 |
| 快捷键 | 常用操作 |
| 响应式 | 移动端适配 |

### 复杂交互额外检查

| 场景 | 必需功能 |
|------|----------|
| 工作流/编辑器 | 节点增删、连线、撤销、重做、多选、导出导入 |
| 列表管理 | 多选、批量操作、排序、筛选、分页 |
| 表单 | 实时校验、错误提示、自动保存 |

### 前后端协同流程

```text
1. frontend-dev 产出 `.claude/memory/decisions/[功能名]-功能论证.md`
2. backend-dev 基于功能论证产出 `.claude/memory/decisions/[功能名]-API契约.md`
3. reviewer / orchestrator 产出 `.claude/workspace/contracts/[功能名]-alignment.json`
4. alignment.status = aligned 后开始实现
```

## 项目记忆目录结构

所有项目记忆存储在项目根目录的 `.claude/` 下：

```text
<project>/
└── .claude/
    ├── skills/
    ├── agents/
    ├── agents.manifest.json
    ├── memory/
    │   ├── project-spec.md
    │   ├── architecture/
    │   │   ├── frontend.md
    │   │   ├── backend.md
    │   │   └── database.md
    │   ├── decisions/
    │   │   ├── [功能名]-功能论证.md
    │   │   └── [功能名]-API契约.md
    │   └── team/
    ├── rules/
    ├── workspace/
    │   ├── framework.json
    │   ├── assignments.json
    │   ├── state.json
    │   ├── review.json
    │   ├── reports/
    │   ├── contracts/
    │   ├── events/
    │   └── logs/
    └── config.json
```

## 智能路由

根据 `agents.manifest.json` 自动派遣合适的 Agent：

| 关键词 | 派遣 Agent | 职责 |
|--------|-----------|------|
| 前端 / UI / 组件 / react / vue / 样式 | frontend-dev | 功能论证 + 前端实现 |
| 后端 / API / 接口 / node / python / go | backend-dev | API 契约 + 后端实现 |
| bug / 修复 / 错误 / 崩溃 / 异常 | bug-fixer | 复现 → 定位 → 修复 → 验证 |
| 数据库 / SQL / 迁移 | db-admin | 迁移 / 回滚 / 验证 |
| 安全 / 漏洞 / 渗透 | security-expert | 风险分级 / 修复建议 |

## 跨窗口并行

### 调度原则

不再使用简单的“并行数 > 4 自动开新窗口”，改用容量模型：

```text
如果 可用执行槽位 < 待调度任务数 且 当前窗口数 < maxWindows：
    启动新窗口
否则：
    优先复用已有窗口
```

### 窗口池

| 窗口 | 容量 | 角色 |
|------|------|------|
| main | 4 | orchestrator + worker |
| window-2 | 2 | worker-host |
| window-3 | 2 | worker-host |
| window-4 | 2 | worker-host |

### 关键脚本

- `scripts/spawn-window.ps1` - 容量判断 + 启动新窗口
- `scripts/register-window.ps1` - 新窗口注册
- `scripts/release-window.ps1` - 释放窗口
- `scripts/window-health-check.ps1` - 扫描 stale / offline 窗口

### 状态同步

所有窗口通过运行时协议协同：
- `framework.json`：静态任务框架
- `assignments.json`：调度账本
- `state.json`：活体运行状态
- `reconcile-state.ps1`：汇总与修正

## 配置参数

```json
{
  "triggers": {
    "complexityThreshold": 5
  },
  "limits": {
    "maxDecompositionDepth": 3,
    "maxSubtasks": 8,
    "maxParallelAgents": 8
  },
  "crossWindowExecution": {
    "enabled": true,
    "maxWindows": 4,
    "mainCapacity": 4,
    "subCapacity": 2,
    "heartbeatIntervalMs": 30000,
    "heartbeatTimeoutMs": 90000,
    "spawnMethod": "powershell -File scripts/spawn-window.ps1"
  },
  "stateSync": {
    "strategy": "coordinator-singleton",
    "coordinatorRole": "orchestrator"
  },
  "featureAnalysis": {
    "enabled": true,
    "requireReferenceCases": true,
    "requireApiContract": true
  }
}
```

## 使用示例

```text
用户: /orchestrate 实现一个工作流编辑器

系统:
  1. 触发功能论证阶段
  2. frontend-dev 生成功能清单
  3. backend-dev 生成 API 契约
  4. reviewer 产出 alignment.json
  5. Orchestrator 生成 framework.json / assignments.json / state.json
  6. Worker Pool 基于容量模型并行执行
  7. Reviewer 做协作审查
  8. Archiver 归档
```

## 文件结构

```text
task-orchestration-v2/
├── README.md                     # 工作流说明
├── skill.md                      # 可执行 Skill（/orchestrate /debt-check）
├── config.json                   # 全局配置
├── agents.manifest.json          # Agent 统一清单
├── architecture-v2.1-simple.svg  # 架构图
├── docs/
│   ├── state-sync.md                    # 状态同步协议
│   ├── cross-window-execution.md        # 跨窗口执行
│   ├── agent-catalog.md                 # Agent 角色目录
│   ├── specialized-agent-coordination.md # Agent 协作协议
│   ├── factor-memory-system.md          # 因子化记忆设计
│   └── vector-memory-engine.md          # 向量记忆引擎
├── prompts/
│   ├── orchestrator.md           # 主控调度
│   ├── worker.md                 # Worker 执行
│   ├── reviewer.md               # 审查验证
│   ├── archiver.md               # 归档
│   └── bug-fixer.md              # Bug 修复专家
├── schemas/
│   ├── framework.schema.json     # 任务框架 schema
│   ├── state.schema.json         # 运行时状态 schema
│   ├── assignments.schema.json   # 调度账本 schema
│   ├── review.schema.json        # 审查报告 schema
│   ├── report.schema.json        # 任务报告 schema
│   ├── alignment.schema.json     # 对齐检查 schema
│   └── factor-record.schema.json # 因子记录 schema
├── scripts/
│   ├── init-workspace-state.ps1  # 初始化工作区
│   ├── spawn-window.ps1          # 启动新窗口
│   ├── register-window.ps1       # 窗口注册
│   ├── release-window.ps1        # 释放窗口
│   ├── window-health-check.ps1   # 窗口健康扫描
│   ├── heartbeat.ps1             # 心跳刷新
│   ├── claim-task.ps1            # 认领任务
│   ├── release-task.ps1          # 释放任务
│   ├── reconcile-state.ps1       # 状态汇总
│   ├── search-similar.ps1        # 向量检索
│   ├── debt-check.ps1            # 代码债务检测
│   ├── index-factor.ps1          # 因子入库
│   └── setup-vector-memory.ps1   # 向量引擎安装
├── tools/
│   └── vector-memory.py          # 向量引擎核心
├── templates/
│   ├── project-spec.md           # 项目规范模板
│   ├── constraints.md            # 硬性约束模板
│   ├── code-style.md             # 代码风格模板
│   ├── task-framework.json       # 任务框架模板
│   ├── task-report.json          # 任务报告模板
│   └── project-agents/
│       ├── frontend-dev.md       # 前端专家
│       ├── backend-dev.md        # 后端专家
│       ├── bug-fixer.md          # Bug 修复
│       ├── db-admin.md           # 数据库管理
│       └── security-expert.md    # 安全审计
└── memory/
    ├── README.md                 # 记忆系统说明
    └── architecture/
        ├── frontend.md           # 前端架构规范
        ├── backend.md            # 后端架构规范
        └── database.md           # 数据库架构规范
```

## 向量记忆引擎

### 解决的问题

Agent 只会写新代码不会删旧代码。向量记忆引擎通过因子分解 + ChromaDB 本地向量库，让 Agent 能：
1. 检索历史相似因子
2. 检测"被替代但未清理"的旧代码
3. 强制声明替换关系

### 安装

```bash
pip install chromadb sentence-transformers -q
```

### 使用

```bash
# 初始化向量库
python .claude/tools/vector-memory.py init

# 检索相似历史任务
python .claude/tools/vector-memory.py search "auth module refactoring"

# 检测代码债务
python .claude/tools/vector-memory.py debt

# 存储因子记录
python .claude/tools/vector-memory.py store .claude/workspace/reports/SUB-001-factor.json

# 查看统计
python .claude/tools/vector-memory.py stats
```

### Agent 集成

Agent 启动时自动：
1. `search "当前任务描述"` — 检索相似历史
2. `debt` — 检查代码债务
3. 发现未清理代码 → 优先清理

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v2.1.0 | 2026-05 | 完整协议、脚本、协作清单与 schema 收口 |
| v2.0.0 | 2024-01 | 新增架构论证、跨窗口并行概念 |
| v1.0.0 | 2024-01 | 初始版本 |
