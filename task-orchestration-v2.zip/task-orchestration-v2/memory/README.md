# 项目记忆系统 v2.1

## 目录结构

所有项目记忆存储在项目根目录的 `.claude/` 下：

```
<project>/
└── .claude/
    ├── skills/                      # 项目级 Skill（覆盖系统）
    ├── agents/                      # 项目级 Agent
    ├── agents.manifest.json         # Agent 统一清单
    │
    ├── memory/                      # 项目记忆（AI 可读取）
    │   ├── project-spec.md          # 项目技术规范
    │   ├── architecture/            # 架构决策记录
    │   │   ├── frontend.md          # 前端架构
    │   │   ├── backend.md           # 后端架构
    │   │   └── database.md          # 数据库架构
    │   ├── decisions/               # 决策记录 + 功能论证 + API契约
    │   │   ├── 001-use-vue3.md
    │   │   ├── [功能名]-功能论证.md  # 前端功能分析
    │   │   └── [功能名]-API契约.md   # 前后端接口约定
    │   └── team/
    │       ├── code-style.md
    │       └── review-checklist.md
    │
    ├── rules/                       # 规则约束
    │   ├── project-spec.md
    │   └── constraints.md
    │
    ├── workspace/                   # 工作区（运行时）
    │   ├── state.json               # 活体运行时状态
    │   ├── framework.json           # 静态任务框架
    │   ├── assignments.json         # 调度账本
    │   ├── review.json              # 审查结果
    │   ├── reports/                 # Agent 报告
    │   │   ├── SUB-001.json
    │   │   └── ...
    │   ├── contracts/               # 对齐检查
    │   │   └── [功能名]-alignment.json
    │   ├── events/                  # 事件日志
    │   └── logs/                    # 执行日志
    │
    └── config.json                  # 项目配置
```

## 三类核心文件

| 文件 | 类型 | 写入者 | 频率 |
|------|------|--------|------|
| framework.json | 静态框架 | Orchestrator | 任务开始时 + 低频追加 |
| assignments.json | 调度账本 | Coordinator 主，Worker 辅 | 认领/完成时 |
| state.json | 活体状态 | 受控脚本 + reconcile 汇总 | 心跳/认领/释放/每 15s 汇总 |

## 记忆读取规则

Agent 在执行任务时，**必须**按以下顺序读取记忆：

```
1. .claude/CLAUDE.md
2. .claude/memory/project-spec.md
3. .claude/memory/architecture/frontend.md (前端任务)
4. .claude/memory/architecture/backend.md (后端任务)
5. .claude/memory/architecture/database.md (数据库任务)
6. .claude/rules/constraints.md
7. .claude/memory/team/code-style.md
```

## 功能论证产物

| 产物 | 路径 | 产出者 |
|------|------|--------|
| 功能论证报告 | `.claude/memory/decisions/[功能名]-功能论证.md` | frontend-dev |
| API 契约 | `.claude/memory/decisions/[功能名]-API契约.md` | backend-dev |
| 对齐检查 | `.claude/workspace/contracts/[功能名]-alignment.json` | reviewer |

## 状态文件格式

### state.json

```json
{
  "version": "2.1",
  "taskId": "task-2026-001",
  "status": "running",
  "phase": "worker",
  "heartbeatIntervalMs": 30000,
  "summary": { "total": 8, "pending": 2, "running": 3, "completed": 3, "failed": 0 },
  "windows": {
    "main": { "status": "busy", "pid": 1001, "role": "orchestrator", "capacity": 4, "runningTasks": [] }
  },
  "subtasks": {
    "SUB-001": { "status": "running", "leaseVersion": 3 }
  }
}
```

### assignments.json

```json
{
  "version": "2.1",
  "taskId": "task-2026-001",
  "assignments": {
    "SUB-001": {
      "status": "claimed",
      "agentType": "frontend-dev",
      "assignedWindow": "main",
      "claimedAt": "2026-05-03T07:14:00Z",
      "leaseExpiresAt": "2026-05-03T07:24:00Z"
    }
  }
}
```

## 脚本

| 脚本 | 职责 |
|------|------|
| `scripts/init-workspace-state.ps1` | 初始化所有运行时文件 |
| `scripts/spawn-window.ps1` | 容量判断 + 启动新窗口 |
| `scripts/register-window.ps1` | 窗口注册 |
| `scripts/release-window.ps1` | 释放窗口 |
| `scripts/window-health-check.ps1` | 心跳扫描 |
| `scripts/heartbeat.ps1` | 心跳刷新 |
| `scripts/claim-task.ps1` | 认领任务 |
| `scripts/release-task.ps1` | 释放任务 |
| `scripts/reconcile-state.ps1` | 状态汇总 |

## 记忆更新机制

1. **每次任务完成后** → Archiver 更新 `project-spec.md`
2. **架构变更时** → 创建新的 ADR 文档
3. **功能论证完成时** → coordinator 写入 decisions/
4. **规则变更时** → 更新 `constraints.md`
