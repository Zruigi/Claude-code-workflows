# 前端架构规范

## 基础信息

| 属性 | 值 |
|------|-----|
| 框架 | Vue 3 / React |
| 语言 | TypeScript |
| 状态管理 | Pinia / Zustand |
| 路由 | Vue Router / React Router |
| HTTP 客户端 | Axios / Fetch |

## 目录结构

```
src/
├── api/                      # API 请求层
│   ├── index.ts              # axios 实例配置
│   ├── user.ts               # 用户相关 API
│   └── ...
│
├── assets/                   # 静态资源
│   ├── images/
│   ├── fonts/
│   └── styles/
│       ├── variables.less    # CSS 变量
│       ├── mixins.less       # 混入
│       └── global.less       # 全局样式
│
├── components/               # 公共组件
│   ├── common/               # 通用组件
│   │   ├── Button/
│   │   ├── Input/
│   │   ├── Modal/
│   │   └── ...
│   ├── business/             # 业务组件
│   │   ├── UserCard/
│   │   └── ...
│   └── layout/               # 布局组件
│       ├── Header/
│       ├── Sidebar/
│       └── ...
│
├── composables/              # Vue 组合式函数
│   ├── useAuth.ts
│   ├── useFetch.ts
│   └── usePermission.ts
│
├── hooks/                    # React Hooks
│   ├── useAuth.ts
│   ├── useFetch.ts
│   └── usePermission.ts
│
├── pages/                    # 页面组件
│   ├── Home/
│   │   ├── index.tsx
│   │   ├── components/       # 页面私有组件
│   │   └── styles.module.less
│   ├── User/
│   └── ...
│
├── router/                   # 路由配置
│   ├── index.ts
│   ├── routes.ts
│   └── guards.ts             # 路由守卫
│
├── store/                    # 状态管理
│   ├── index.ts
│   ├── user.ts               # 用户状态
│   └── settings.ts           # 设置状态
│
├── types/                    # TypeScript 类型
│   ├── api.d.ts              # API 响应类型
│   ├── user.d.ts
│   └── ...
│
├── utils/                    # 工具函数
│   ├── format.ts             # 格式化
│   ├── validate.ts           # 校验
│   └── storage.ts            # 本地存储
│
├── views/                    # 视图（可选，替代 pages）
│
├── App.vue                   # 根组件
├── main.ts                   # 入口文件
└── env.d.ts                  # 环境变量类型
```

---

## 功能论证阶段

在实现任何功能前，必须完成功能论证。

### Step 1: 功能清单生成

**必须考虑的基础功能要素**：

| 类别 | 必需功能 | 说明 |
|------|----------|------|
| **CRUD** | 增/删/改/查 | 任何业务的基础 |
| **选择** | 单选/多选 | 批量操作前提 |
| **删除** | 单删/批量删 | 删除前确认弹窗 |
| **撤销** | 撤销/重做 | 修改后悔药 |
| **保存** | 自动保存/手动保存 | 防丢失 |
| **加载** | 骨架屏/Loading | 体验优化 |
| **空状态** | 空数据展示 | 友好提示 |
| **错误** | 错误提示/重试 | 容错处理 |
| **快捷键** | 常用操作 | 效率提升 |
| **响应式** | 移动端适配 | 多端支持 |
| **持久化** | 本地存储/缓存 | 状态保持 |

### Step 2: 复杂交互额外考虑

| 场景 | 额外考虑 |
|------|----------|
| **工作流/编辑器** | 节点增删改、连线、撤销、重做、快捷键、导出导入 |
| **列表管理** | 多选、批量操作、排序、筛选、分页 |
| **表单** | 实时校验、错误提示、自动保存、键盘导航 |
| **图表** | 数据为空、加载中、交互提示、响应式 |
| **弹窗** | 点击遮罩关闭、ESC 关闭、滚动穿透 |
| **拖拽** | 拖动中样式、放置位置提示、取消拖动 |

### Step 3: 参考案例收集

**在实现前，搜索相关开源项目作为参考**：

```bash
# 搜索关键词示例
# 工作流: "workflow editor react vue"
# 图表: "chart library react"
# 编辑器: "rich text editor react"

# 参考来源
- GitHub trending
- npm trends
- awesome-xxx 列表
```

**收集内容**：
1. 类似功能的开源项目
2. 核心功能点清单
3. 用户体验亮点
4. 已知问题/坑

**输出到**: `.claude/memory/decisions/功能名-参考案例.md`

### Step 4: 功能清单模板

```markdown
# 功能论证: [功能名称]

## 功能概述
[一句话描述]

## 核心功能点

### 必需实现
- [ ] 功能点1
- [ ] 功能点2
- [ ] ...

### 可选优化
- [ ] 优化点1
- [ ] ...

## 参考案例

| 项目 | 亮点 | 链接 |
|------|------|------|
| project-1 | xxx | url |
| project-2 | xxx | url |

## 与后端 API 对照

| 前端操作 | API 接口 | 状态 |
|----------|----------|------|
| 获取列表 | GET /api/xxx | 待确认 |
| 创建 | POST /api/xxx | 待确认 |
| 删除 | DELETE /api/xxx/:id | 待确认 |
```

---

## 组件规范

### 组件目录结构

```
MyComponent/
├── index.vue                 # 组件入口
├── MyComponent.vue           # 组件实现
├── MyComponent.props.ts      # Props 类型定义
├── MyComponent.emits.ts      # Emits 类型定义
├── MyComponent.spec.ts       # 单元测试
├── MyComponent.e2e.ts        # E2E 测试
├── useMyComponent.ts         # 组合式函数（Vue）
└── styles.module.scss        # 样式文件
```

### 组件命名规范

| 类型 | 规范 | 示例 |
|------|------|------|
| 文件名 | 大驼峰 | `UserCard.vue` |
| 组件名 | 大驼峰 | `UserCard` |
| Props | 小驼峰 | `userName` |
| Events | 纯事件名 | `click` |
| Slots | 纯小写 | `default` |

### Props 定义（Vue）

```typescript
interface Props {
  /** 用户名称 */
  userName: string;
  /** 用户头像 URL */
  avatar?: string;
  /** 是否禁用 */
  disabled?: boolean;
  /** 点击回调 */
  onClick?: (user: User) => void;
}
```

### Props 定义（React）

```typescript
interface UserCardProps {
  /** 用户名称 */
  userName: string;
  /** 用户头像 URL */
  avatar?: string;
  /** 是否禁用 */
  disabled?: boolean;
  /** 点击回调 */
  onClick?: (user: User) => void;
}
```

## 样式规范

### CSS 命名规范

使用 BEM 或 CSS Modules：

```scss
// BEM
.block {}
block__element {}
block--modifier {}

// CSS Modules
.styles.container {}
.styles.active {}
```

### 响应式断点

```scss
$breakpoints: (
  'sm': 576px,   // 手机
  'md': 768px,   // 平板
  'lg': 992px,   // 小屏笔记本
  'xl': 1200px,  // 桌面
  'xxl': 1400px  # 大屏桌面
);
```

### 主题变量

```scss
// variables.scss
:root {
  // 颜色
  --color-primary: #1890ff;
  --color-success: #52c41a;
  --color-warning: #faad14;
  --color-error: #f5222d;
  
  // 字体
  --font-size-base: 14px;
  --font-size-lg: 16px;
  
  // 间距
  --spacing-xs: 4px;
  --spacing-sm: 8px;
  --spacing-md: 16px;
  --spacing-lg: 24px;
}
```

## 状态管理规范

### Pinia Store 结构

```typescript
// stores/user.ts
import { defineStore } from 'pinia';

interface UserState {
  info: User | null;
  token: string | null;
  permissions: string[];
}

export const useUserStore = defineStore('user', {
  state: (): UserState => ({
    info: null,
    token: null,
    permissions: [],
  }),
  
  getters: {
    isLoggedIn: (state) => !!state.token,
    userName: (state) => state.info?.name ?? '未登录',
  },
  
  actions: {
    async login(credentials: LoginDTO) {
      const res = await api.login(credentials);
      this.token = res.token;
      this.info = res.user;
    },
    
    logout() {
      this.token = null;
      this.info = null;
      this.permissions = [];
    },
  },
});
```

### Zustand Store 结构

```typescript
// stores/user.ts
import { create } from 'zustand';

interface UserState {
  info: User | null;
  token: string | null;
  login: (credentials: LoginDTO) => Promise<void>;
  logout: () => void;
}

export const useUserStore = create<UserState>((set) => ({
  info: null,
  token: null,
  
  login: async (credentials) => {
    const res = await api.login(credentials);
    set({ token: res.token, info: res.user });
  },
  
  logout: () => set({ token: null, info: null }),
}));
```

## API 请求规范

### 请求拦截器

```typescript
// api/index.ts
const instance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 10000,
});

// 请求拦截
instance.interceptors.request.use(
  (config) => {
    const token = userStore.token;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 响应拦截
instance.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response?.status === 401) {
      userStore.logout();
      router.push('/login');
    }
    return Promise.reject(error);
  }
);
```

### API 模块定义

```typescript
// api/user.ts
import axios from './index';

export const userApi = {
  /** 获取用户信息 */
  getUserInfo: () => axios.get('/user/info'),
  
  /** 更新用户信息 */
  updateUserInfo: (data: UpdateUserDTO) => axios.put('/user/info', data),
  
  /** 修改密码 */
  changePassword: (data: ChangePasswordDTO) => 
    axios.post('/user/change-password', data),
};
```

## 路由规范

### 路由守卫

```typescript
// router/guards.ts
import { createRouter, createWebHistory } from 'vue-router';
import { useUserStore } from '@/store/user';

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/pages/Home'),
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/pages/Login'),
    meta: { public: true },
  },
  {
    path: '/admin',
    name: 'Admin',
    component: () => import('@/pages/Admin'),
    meta: { requiresAuth: true, role: 'admin' },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to, from, next) => {
  const userStore = useUserStore();
  
  if (to.meta.requiresAuth && !userStore.isLoggedIn) {
    next('/login');
  } else if (to.meta.role && userStore.info?.role !== to.meta.role) {
    next('/403');
  } else {
    next();
  }
});

export default router;
```

## 性能优化规范

| 优化点 | 实现方式 |
|--------|----------|
| 代码分割 | 路由懒加载 + 动态导入 |
| 图片优化 | WebP 格式 + 懒加载 |
| 缓存 | Pinia 持久化 + 资源缓存 |
| 首屏优化 | SSR / SSG / 预渲染 |
| 包体积 | Tree Shaking + 压缩 |

## 测试规范

### 单元测试（Vitest）

```typescript
// components/Button/Button.spec.ts
import { render, screen } from '@testing-library/vue';
import Button from './Button.vue';

describe('Button', () => {
  it('renders correctly', () => {
    render(Button, {
      props: { type: 'primary' },
      slots: { default: 'Click me' },
    });
    
    expect(screen.getByText('Click me')).toBeTruthy();
  });
  
  it('emits click event', async () => {
    const { emitted } = render(Button);
    await screen.getByRole('button').click();
    
    expect(emitted()).toHaveProperty('click');
  });
});
```

### E2E 测试（Playwright）

```typescript
// e2e/login.spec.ts
import { test, expect } from '@playwright/test';

test('login flow', async ({ page }) => {
  await page.goto('/login');
  
  await page.fill('[data-testid=username]', 'testuser');
  await page.fill('[data-testid=password]', 'password123');
  await page.click('[data-testid=submit]');
  
  await expect(page).toHaveURL('/dashboard');
});
```

## 构建规范

### Vite 配置

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { resolve } from 'path';

export default defineConfig({
  plugins: [vue()],
  
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },
  
  build: {
    target: 'es2015',
    cssCodeSplit: true,
    rollupOptions: {
      output: {
        manualChunks: {
          'vendor': ['vue', 'vue-router', 'pinia'],
          'ui': ['element-plus'],
        },
      },
    },
  },
  
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true,
      },
    },
  },
});
```

## 环境变量

| 变量 | 说明 | 示例 |
|------|------|------|
| VITE_API_BASE_URL | API 基础地址 | `/api` |
| VITE_APP_TITLE | 应用标题 | My App |
| VITE_ENABLE_MOCK | 是否启用 Mock | `true` |
| VITE_ANALYTICS_ID | 埋点 ID | UA-XXX |

---

## 前端任务检查清单

每个前端任务完成后，必须验证：

- [ ] CRUD 完整（增删改查）
- [ ] 选择功能（单选/多选）
- [ ] 删除确认弹窗
- [ ] 撤销/重做（如适用）
- [ ] 加载状态（骨架屏/Loading）
- [ ] 空数据状态展示
- [ ] 错误处理与重试
- [ ] 响应式适配
- [ ] 快捷键支持（如适用）
- [ ] 与后端 API 对照无误