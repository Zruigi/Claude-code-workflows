# 后端架构规范

## 架构决策框架

当项目未指定后端技术栈时，需通过以下决策流程选择最佳方案：

### 决策流程

```
┌─────────────────────────────────────────────────────────────┐
│  Step 1: 业务类型分析                                        │
├─────────────────────────────────────────────────────────────┤
│  API 类型: REST / GraphQL / gRPC / WebSocket               │
│  数据特征: 事务型 / 分析型 / 混合型                          │
│  实时性: 同步 / 异步 / 半同步                                │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────��───────────────────────┐
│  Step 2: 性能要求评估                                        │
├─────────────────────────────────────────────────────────────┤
│  QPS 预期: < 100 / 100-1000 / 1000-10000 / > 10000         │
│  延迟要求: < 50ms / < 200ms / < 1s                          │
│  并发量: 低 / 中 / 高                                        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  Step 3: 团队能力评估                                        │
├─────────────────────────────────────────────────────────────┤
│  熟悉语言: [列出团队擅长的语言]                              │
│  学习成本: 可接受 / 需培训                                   │
│  招聘难度: 容易 / 困难                                       │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  Step 4: 生态与维护                                          │
├─────────────────────────────────────────────────────────────┤
│  库/框架成熟度                                               │
│  社区活跃度                                                  │
│  长期维护预期                                                │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────��───��───────────────────────────────────────────┐
│  推荐方案                                                    │
└─────────────────────────────────────────────────────────────┘
```

### 技术选型推荐表

| 场景 | 首推 | 备选 | 不推荐 |
|------|------|------|--------|
| 快速 MVP | Node.js + Express/Nest | Python FastAPI | Go (开发慢) |
| 高并发 API | Go + Gin | Node.js + Fastify | Python |
| 实时聊天 | Node.js + Socket.io | Go + Gorilla | Python |
| 数据处理 | Python | Node.js | Go |
| 微服务 | Go | Node.js | Python |
| AI/ML 后端 | Python (FastAPI) | Node.js | Go |
| 企业级应用 | Java Spring | Node.js NestJS | - |
| 区块链/基础设施 | Rust | Go | Python |

## 目录结构

### Node.js (Express/NestJS)

```
src/
├── app.module.ts              # 入口模块
├── main.ts                    # 启动文件
│
├── config/                    # 配置
│   ├── index.ts               # 配置加载
│   ├── development.ts         # 开发环境
│   └── production.ts          # 生产环境
│
├── common/                    # 公共模块
│   ├── decorators/            # 装饰器
│   │   ├── auth.decorator.ts
│   │   └── role.decorator.ts
│   ├── guards/                # 守卫
│   │   └── auth.guard.ts
│   ├── filters/               # 异常过滤器
│   │   └── http-exception.filter.ts
│   ├── interceptors/          # 拦截器
│   │   └── logging.interceptor.ts
│   └── pipes/                 # 管道
│       └── validation.pipe.ts
│
├── modules/                   # 功能模块
│   ├── user/
│   │   ├── user.module.ts
│   │   ├── user.controller.ts # API 接口
│   │   ├── user.service.ts    # 业务逻辑
│   │   ├── user.entity.ts     # 数据模型
│   │   ├── user.dto.ts        # 数据传输对象
│   │   ├── user.repository.ts # 数据访问
│   │   └── user.spec.ts       # 单元测试
│   └── ...
│
├── database/                  # 数据库
│   ├── migrations/            # 迁移文件
│   ├── seeders/               # 种子数据
│   └── entities/              # ORM 实体
│
├── middleware/                # 中间件
│   ├── auth.middleware.ts
│   ├── cors.middleware.ts
│   └── logger.middleware.ts
│
├── utils/                     # 工具函数
│   ├── crypto.ts              # 加密
│   ├── datetime.ts            # 日期时间
│   └── validator.ts           # 校验
│
├── types/                     # 类型定义
│   ├── express.d.ts
│   └── ...
│
└── tests/                     # 测试
    ├── e2e/
    └── mocks/
```

### Python (FastAPI/Django)

```
src/
├── main.py                    # 入口
├── config.py                  # 配置
│
├── app/
│   ├── __init__.py
│   ├── api/                   # API 路由
│   │   ├── v1/
│   │   │   ├── users.py
│   │   │   └── __init__.py
│   │   └── __init__.py
│   │
│   ├── core/                  # 核心模块
│   │   ├── security.py        # 安全
│   │   ├── database.py        # 数据库
│   │   └── exceptions.py      # 异常
│   │
│   ├── models/                # 数据模型
│   │   ├── user.py
│   │   └── base.py
│   │
│   ├── schemas/               # Pydantic 模型
│   │   ├── user.py
│   │   └── base.py
│   │
│   ├── services/              # 业务逻辑
│   │   ├── user_service.py
│   │   └── __init__.py
│   │
│   └── utils/                 # 工具
│       ├── crypto.py
│       └── validator.py
│
├── alembic/                   # 迁移
│   ├── env.py
│   └── versions/
│
└── tests/
    ├── conftest.py
    ├── api/
    └── unit/
```

### Go (Gin)

```
src/
├── main.go                    # 入口
├── go.mod
│
├── config/                    # 配置
│   └── config.go
│
├── internal/                  # 内部包
│   ├── handler/               # HTTP 处理
│   │   ├── user.go
│   │   └── health.go
│   │
│   ├── service/               # 业务逻辑
│   │   ├── user.go
│   │   └── auth.go
│   │
│   ├── repository/            # 数据访问
│   │   ├── user.go
│   │   └── postgres.go
│   │
│   ├── model/                 # 数据模型
│   │   ├── user.go
│   │   └── base.go
│   │
│   ├── middleware/            # 中间件
│   │   ├── auth.go
│   │   └── logger.go
│   │
│   └── utils/                 # 工具
│       ├── crypto.go
│       └── validator.go
│
├── migrations/                # 数据库迁移
│
├── cmd/                       # 命令行入口
│   └── server/
│       └── main.go
│
└── tests/
    ├── handler_test.go
    └── integration_test.go
```

---

## 功能论证阶段（前后端协同）

在实现任何功能前，后端必须与前端协同完成功能论证。

### Step 1: 等待前端功能清单

**后端必须等待前端完成功能论证后再开始设计 API**。

前端会提供：
- 功能清单（必需功能 + 可选优化）
- 每个功能需要的 API 操作
- 用户交互流程

### Step 2: API 设计

基于前端功能清单，设计对应的 API：

| 前端操作 | HTTP 方法 | API 路径 | 请求体 | 响应 |
|----------|-----------|----------|--------|------|
| 获取列表 | GET | /api/xxx | - | { data: [], total: N } |
| 创建 | POST | /api/xxx | { ... } | { data: {} } |
| 更新 | PUT | /api/xxx/:id | { ... } | { data: {} } |
| 删除 | DELETE | /api/xxx/:id | - | { success: true } |
| 批量删除 | POST | /api/xxx/batch-delete | { ids: [] } | { success: true } |

### Step 3: 前后端接口契约

**生成接口契约文档**，包含：

```markdown
# 接口契约: [功能名称]

## API 列表

### 1. 获取列表
- **接口**: `GET /api/xxx`
- **请求参数**:
  - page: number (默认 1)
  - pageSize: number (默认 20)
  - search?: string
  - sortBy?: string
  - sortOrder?: 'asc' | 'desc'
- **响应**:
```json
{
  "code": 200,
  "data": [],
  "pagination": {
    "page": 1,
    "pageSize": 20,
    "total": 100
  }
}
```

### 2. 创建
- **接口**: `POST /api/xxx`
- **请求体**: `{ name: string, ... }`
- **响应**: `{ code: 201, data: { id: 1 } }`

### 3. 删除
- **接口**: `DELETE /api/xxx/:id`
- **响应**: `{ code: 204 }`

## 数据模型

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| id | number | 是 | 主键 |
| name | string | 是 | 名称 |
| createdAt | datetime | 是 | 创建时间 |
| updatedAt | datetime | 是 | 更新时间 |

## 业务规则

1. 删除前检查关联数据
2. 名称唯一性校验
3. 软删除 vs 硬删除
```

### Step 4: 错误码对照

前后端必须统一错误码：

| 错误码 | 含义 | 前端处理 |
|--------|------|----------|
| 200 | 成功 | 正常处理 |
| 201 | 创建成功 | 跳转/提示 |
| 400 | 参数错误 | 表单提示 |
| 401 | 未登录 | 跳转登录 |
| 403 | 无权限 | 提示权限不足 |
| 404 | 资源不存在 | 提示不存在 |
| 409 | 业务冲突 | 提示原因 |
| 422 | 业务逻辑错误 | 提示错误信息 |
| 500 | 服务器错误 | 提示稍后重试 |

### Step 5: 输出到

```
.claude/memory/decisions/[功能名]-API契约.md
```

---

## API 设计规范

### RESTful 命名

| 操作 | 方法 | 路径 | 示例 |
|------|------|------|------|
| 获取列表 | GET | /users | GET /users |
| 获取单个 | GET | /users/:id | GET /users/1 |
| 创建 | POST | /users | POST /users |
| 更新(全) | PUT | /users/:id | PUT /users/1 |
| 更新(部分) | PATCH | /users/:id | PATCH /users/1 |
| 删除 | DELETE | /users/:id | DELETE /users/1 |
| 批量删除 | POST | /users/batch-delete | POST /users/batch-delete |

### 响应格式

```typescript
// 成功响应
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "name": "John"
  },
  "pagination": {
    "page": 1,
    "pageSize": 20,
    "total": 100
  }
}

// 错误响应
{
  "code": 400,
  "message": "参数错误",
  "errors": [
    {
      "field": "email",
      "message": "邮箱格式不正确"
    }
  ]
}
```

### 状态码规范

| 状态码 | 含义 | 使用场景 |
|--------|------|----------|
| 200 | OK | 成功获取/更新 |
| 201 | Created | 成功创建 |
| 204 | No Content | 成功删除 |
| 400 | Bad Request | 参数错误 |
| 401 | Unauthorized | 未登录 |
| 403 | Forbidden | 无权限 |
| 404 | Not Found | 资源不存在 |
| 409 | Conflict | 资源冲突 |
| 422 | Unprocessable | 业务逻辑错误 |
| 500 | Internal Server Error | 服务器错误 |

## 数据库规范

### ORM 使用规范

**Node.js (Prisma)**
```typescript
// schema.prisma
model User {
  id        Int      @id @default(autoincrement())
  email     String   @unique
  name      String?
  posts     Post[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Post {
  id        Int      @id @default(autoincrement())
  title     String
  content   String?
  author    User     @relation(fields: [authorId], references: [id])
  authorId  Int
}
```

**Python (SQLAlchemy)**
```python
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    name = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)
```

### 索引规范

| 场景 | 索引类型 | 示例 |
|------|----------|------|
| 主键 | PRIMARY | id |
| 唯一字段 | UNIQUE | email |
| 经常查询 | INDEX | user_id + status |
| 全文搜索 | FULLTEXT | title + content |
| 范围查询 | INDEX | created_at |

### 事务规范

```typescript
// 正确使用事务
await prisma.$transaction(async (tx) => {
  // 操作1: 创建用户
  const user = await tx.user.create({
    data: { email, name }
  });
  
  // 操作2: 分配角色
  await tx.userRole.create({
    data: { userId: user.id, roleId: roleId }
  });
  
  return user;
});
```

## 安全规范

### 认证

```typescript
// JWT 验证
interface JWTPayload {
  userId: number;
  email: string;
  role: string;
  exp: number;
}

// Token 验证中间件
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: '未提供 token' });
  }
  
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'token 无效' });
  }
};
```

### 权限控制

```typescript
// RBAC 权限模型
enum Role {
  ADMIN = 'admin',
  USER = 'user',
  GUEST = 'guest'
}

const permissions = {
  [Role.ADMIN]: ['*'],
  [Role.USER]: ['user:read', 'user:update', 'post:read'],
  [Role.GUEST]: ['post:read']
};

// 权限检查装饰器
@RequirePermissions('user:create')
async function createUser(req, res) {
  // 创建用户逻辑
}
```

### 数据加密

| 数据类型 | 加密方式 | 场景 |
|----------|----------|------|
| 密码 | bcrypt/argon2 | 用户密码存储 |
| 敏感字段 | AES-256 | 身份证、手机号 |
| 传输 | TLS 1.3 | API 通信 |
| 签名 | HMAC-SHA256 | API 验签 |

### SQL 注入防护

```typescript
// 正确：使用参数化查询
const user = await prisma.user.findFirst({
  where: { email: userInput.email }  // Prisma 自动处理
});

// 错误：字符串拼接
const user = await prisma.$queryRaw`
  SELECT * FROM users WHERE email = ${userInput.email}
`;
```

### CORS 配置

```typescript
// 生产环境严格配置
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS.split(','),
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  maxAge: 86400,
}));
```

## 日志规范

### 日志级别

| 级别 | 含义 | 使用场景 |
|------|------|----------|
| debug | 调试信息 | 开发环境 |
| info | 正常流程 | API 请求、状态变化 |
| warn | 警告 | 可恢复的错误 |
| error | 错误 | 异常、失败 |

### 日志格式

```json
{
  "timestamp": "2024-01-15T10:30:00.000Z",
  "level": "info",
  "message": "User login",
  "context": {
    "userId": 123,
    "ip": "192.168.1.1",
    "userAgent": "Mozilla/5.0..."
  },
  "request": {
    "method": "POST",
    "path": "/api/auth/login",
    "body": { "email": "xxx" }
  },
  "response": {
    "statusCode": 200,
    "duration": 45
  }
}
```

## 性能优化

### 缓存策略

| 缓存类型 | TTL | 适用场景 |
|----------|-----|----------|
| Redis | 5-60 分钟 | 热点数据、会话 |
| CDN | 1-24 小时 | 静态资源 |
| 内存 | 1-5 分钟 | 配置、枚举 |
| 数据库 | 按需 | 查询结果 |

### N+1 查询防护

```typescript
// 正确：使用 include 预加载
const users = await prisma.user.findMany({
  include: {
    posts: true,  // 一次性加载关联数据
    profile: true
  }
});

// 错误：循环查询
for (const id of userIds) {
  const user = await prisma.user.findUnique({
    where: { id }
  });
}
```

### 连接池配置

```typescript
// Node.js Prisma
const prisma = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL + 
        "?connection_limit=20&pool_timeout=10"
    }
  }
});
```

## 部署规范

### Docker

```dockerfile
# Node.js
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]

# Go
FROM golang:1.21-alpine AS builder
WORKDIR /app
COPY go.mod go.sum ./
RUN go mod download
COPY . .
RUN CGO_ENABLED=0 go build -o server

FROM alpine
WORKDIR /app
COPY --from=builder /app/server .
EXPOSE 8080
CMD ["./server"]
```

### 健康检查

```typescript
// /health 接口
app.get('/health', (req, res) => {
  const health = {
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    checks: {
      database: db.isConnected ? 'ok' : 'error',
      redis: redis.isConnected ? 'ok' : 'error'
    }
  };
  
  const isHealthy = 
    health.checks.database === 'ok' &&
    health.checks.redis === 'ok';
    
  res.status(isHealthy ? 200 : 503).json(health);
});
```

---

## 后端任务检查清单

每个后端任务完成后，必须验证：

- [ ] API 与前端功能清单对应
- [ ] 接口契约文档已生成
- [ ] 错误码与前端统一
- [ ] 参数校验完整
- [ ] 权限控制到位
- [ ] 日志记录完整
- [ ] 单元测试覆盖
- [ ] 数据库索引合理
- [ ] 软删除/硬删除明确