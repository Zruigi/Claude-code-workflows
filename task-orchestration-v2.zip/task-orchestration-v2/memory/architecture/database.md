# 数据库架构规范

## 选型决策框架

### 决策流程

```
┌─────────────────────────────────────────────────────────────┐
│  Step 1: 数据特征分析                                        │
├─────────────────────────────────────────────────────────────┤
│  结构化程度: 强结构 / 半结构 / 非结构                        │
│  数据模型: 关系型 / 文档型 / 图谱 / 向量                    │
│   数据规模: < 1GB / 1GB-100GB / 100GB-1TB / > 1TB          │
│  事务需求: ACID / BASE / 无要求                            │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  Step 2: 查询模式分析                                        │
├─────────────────────────────────────────────────────────────┤
│  复杂查询: 多表 JOIN / 聚合统计 / 全文搜索                  │
│  检索需求: 精确匹配 / 模糊搜索 / 向量相似度                 │
│  实时性: 实时 / 近实时 / 批处理                             │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  Step 3: 性能与扩展性                                        │
├─────────────────────────────────────────────────────────────┤
│  QPS 要求: < 1000 / 1000-10000 / > 10000                   │
│  扩展方式: 垂直 / 水平                                      │
│  一致性要求: 强一致 / 最终一致                              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  推荐方案                                                    │
└─────────────────────────────────────────────────────────────┘
```

### 数据库选型推荐表

| 数据特征 | 首推 | 备选 | 场景举例 |
|----------|------|------|----------|
| 强结构 + 事务 | PostgreSQL | MySQL | 电商订单、金融 |
| 强结构 + 高并发 | MySQL | PostgreSQL | 社交 feed、日志 |
| 半结构 + 灵活 | MongoDB | PostgreSQL JSON | 用户画像、内容管理 |
| 向量 + AI | pgvector/Pinecone | Milvus | 语义搜索、推荐 |
| 图关系 | Neo4j | PostgreSQL + age | 社交网络、推荐系统 |
| 时序数据 | InfluxDB | TimescaleDB | 监控、IoT |
| 缓存 | Redis | Memcached | 会话、热点数据 |
| 搜索 | Elasticsearch | MeiliSearch | 全文搜索、日志 |

## 关系型数据库 (PostgreSQL/MySQL)

### 集群架构

```
┌─────────────────────────────────────────────────────────────┐
│                     负载均衡层                               │
│                    (PgBouncer / ProxySQL)                  │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│  主库 (Primary) ────────→ 从库 (Replica 1)                  │
│       │                       │                              │
│       └───────→ 从库 (Replica 2)                            │
│               │                                                  │
│               └───────→ 从库 (Replica N)                      │
└─────────────────────────────────────────────────────────────┘
```

### 配置参数

#### PostgreSQL 核心配置

```sql
-- postgresql.conf
max_connections = 200
shared_buffers = 256MB           -- 25% RAM
effective_cache_size = 768MB     -- 75% RAM
maintenance_work_mem = 64MB
work_mem = 4MB
checkpoint_completion_target = 0.9
wal_buffers = 16MB
default_statistics_target = 100
random_page_cost = 1.1           -- SSD
effective_io_concurrency = 200
max_worker_processes = 8
max_parallel_workers_per_gather = 4
max_parallel_workers = 8
max_parallel_maintenance_workers = 4

-- 复制配置
wal_level = replica
max_wal_senders = 10
max_replication_slots = 10
hot_standby = on
```

#### MySQL 核心配置

```ini
# my.cnf
max_connections = 500
innodb_buffer_pool_size = 1G     -- 70% RAM
innodb_log_file_size = 256M
innodb_flush_log_at_trx_commit = 1
innodb_flush_method = O_DIRECT
innodb_file_per_table = 1
innodb_io_capacity = 2000
innodb_io_capacity_max = 4000
innodb_read_io_threads = 8
innodb_write_io_threads = 8
max_allowed_packet = 64M
character-set-server = utf8mb4
collation-server = utf8mb4_unicode_ci

# 主从复制
server-id = 1
log-bin = mysql-bin
binlog_format = ROW
binlog_row_image = FULL
expire_logs_days = 7
```

### 高可用方案

| 方案 | 原理 | 优点 | 缺点 |
|------|------|------|------|
| 主从复制 | 主写从读 | 简单、读写分离 | 主从延迟 |
| 双主 | 双向同步 | 高可用 | 写入冲突 |
| Patroni | ETCD 选主 | 自动故障恢复 | 复杂 |
| PgBouncer | 连接池 | 减少连接数 | 额外组件 |

### 备份策略

```bash
# 每日全量备份
0 2 * * * pg_dump -Fc -f /backup/full_$(date +%Y%m%d).dump

# 每小时增量备份
0 * * * * pg_basebackup -X stream -P -D /backup/incremental_$(date +%Y%m%d_%H)

# 保留策略
# 全量: 保留 30 天
# 增量: 保留 7 天
# 归档: 保留 365 天
```

## 向量数据库

### 选型对比

| 数据库 | 向量维度 | 索引算法 | 适用场景 | 缺点 |
|--------|----------|----------|----------|------|
| pgvector | ≤ 2000 | IVFFlat, HNSW | 简单 AI 应用 | 维度有限 |
| Pinecone | 无限 | 专有 | 规模化生产 | 商业付费 |
| Milvus | 无限 | HNSW, IVF | 大规模向量 | 资源消耗大 |
| Weaviate | 无限 | HNSW | 图文搜索 | 社区较小 |
| Qdrant | 无限 | HNSW | 高性能 | 生态较新 |

### pgvector 使用示例

```sql
-- 创建向量扩展
CREATE EXTENSION vector;

-- 创建向量表
CREATE TABLE document_embeddings (
    id BIGSERIAL PRIMARY KEY,
    document_id BIGINT NOT NULL,
    chunk_text TEXT,
    embedding vector(1536),  -- OpenAI ada-002 维度
    created_at TIMESTAMP DEFAULT NOW()
);

-- 创建 HNSW 索引 (推荐生产环境)
CREATE INDEX idx_document_embeddings_embedding 
ON document_embeddings 
USING hnsw (embedding vector_cosine_ops)
WITH (m = 16, ef_construction = 64);

-- 近似最近邻查询
SELECT id, chunk_text, 
       1 - (embedding <=> $1::vector) as similarity
FROM document_embeddings
WHERE embedding <=> $1::vector < 0.3
ORDER BY embedding <=> $1::vector
LIMIT 5;
```

### 混合搜索方案

```sql
-- 向量 + 全文搜索结合
SELECT 
    id,
    chunk_text,
    1 - (embedding <=> $1::vector) as vector_similarity,
    ts_rank(to_tsvector('english', chunk_text), plainto_tsquery($2)) as text_similarity,
    0.7 * (1 - (embedding <=> $1::vector)) + 0.3 * ts_rank(to_tsvector('english', chunk_text), plainto_tsquery($2)) as hybrid_score
FROM document_embeddings
WHERE chunk_text ILIKE $2
   OR embedding <=> $1::vector < 0.5
ORDER BY hybrid_score DESC
LIMIT 10;
```

## 数据加密

### 传输层加密 (TLS)

```yaml
# PostgreSQL
ssl = on
ssl_cert_file = '/etc/ssl/certs/server.crt'
ssl_key_file = '/etc/ssl/private/server.key'
ssl_min_protocol_version = 'TLSv1.2'

# MySQL
require_secure_transport = ON
ssl_ca = '/etc/ssl/certs/ca.pem'
ssl_cert = '/etc/ssl/certs/server.pem'
ssl_key = '/etc/ssl/private/server.key'
```

### 存储层加密

| 加密层级 | 实现方式 | 适用场景 |
|----------|----------|----------|
| 数据库内置 | PostgreSQL pgcrypto | 字段级加密 |
| TDE | 透明数据加密 | 磁盘加密 |
| 文件系统 | LUKS / dm-crypt | 整盘加密 |
| 应用层 | AES-256 | 敏感字段加密 |

### 字段级加密示例

```typescript
// 使用 pgcrypto 加密
const encryptCreditCard = async (cardNumber: string) => {
  // 加密
  const encrypted = await prisma.$queryRaw`
    SELECT pgp_sym_encrypt(${cardNumber}, ${process.env.ENCRYPTION_KEY}) 
    AS encrypted
  `;
  return encrypted[0].encrypted;
};

const decryptCreditCard = async (encrypted: string) => {
  const decrypted = await prisma.$queryRaw`
    SELECT pgp_sym_decrypt(
      ${encrypted}::bytea, 
      ${process.env.ENCRYPTION_KEY}
    ) AS decrypted
  `;
  return decrypted[0].decrypted;
};
```

### 密钥管理

```yaml
# 环境变量 (不推荐生产)
ENCRYPTION_KEY=your-key-here

# HashiCorp Vault (推荐)
vault kv put secret/myapp encryption_key=@(openssl rand -hex 32)

# AWS KMS
aws kms encrypt --key-id alias/myapp --plaintext "mykey"
```

## 安全设定

### 用户权限模型

```sql
-- PostgreSQL 最小权限原则
CREATE ROLE app_readonly WITH LOGIN PASSWORD 'xxx';
GRANT CONNECT ON DATABASE myapp TO app_readonly;
GRANT USAGE ON SCHEMA public TO app_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO app_readonly;
GRANT SELECT ON ALL SEQUENCES IN SCHEMA public TO app_readonly;

-- 业务用户
CREATE ROLE app_service WITH LOGIN PASSWORD 'xxx';
GRANT CONNECT ON DATABASE myapp TO app_service;
GRANT USAGE, CREATE ON SCHEMA public TO app_service;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO app_service;

-- 管理员
CREATE ROLE app_admin WITH LOGIN PASSWORD 'xxx';
GRANT ALL PRIVILEGES ON DATABASE myapp TO app_admin;
GRANT ALL ON SCHEMA public TO app_admin;
```

### 网络隔离

```yaml
# PostgreSQL pg_hba.conf
# 本地连接
local   all             all                                     trust

# 内部网络
host    all             app_server      10.0.0.0/8              md5

# 禁止外部连接
host    all             all             0.0.0.0/0               reject
```

### SQL 注入防护

```typescript
// 正确: 参数化查询
const user = await prisma.user.findUnique({
  where: { email: input.email }
});

// 正确: Prisma ORM
const users = await prisma.user.findMany({
  where: {
    role: input.role,
    createdAt: { gte: input.startDate }
  }
});

// 错误: 字符串拼接
const user = await prisma.$queryRaw`
  SELECT * FROM users WHERE email = ${input.email}
`;
```

### 审计日志

```sql
-- 开启审计
CREATE EXTENSION pgaudit;

-- 配置审计
ALTER SYSTEM SET pgaudit.log = 'WRITE, DDL';
ALTER SYSTEM SET pgaudit.log_catalog = 'off';
ALTER SYSTEM SET pgaudit.log_parameter = 'on';

-- 查看审计日志
SELECT * FROM pg_logical_slots;
SELECT * FROM pgaudit.log;
```

## 性能优化

### 索引设计

| 查询类型 | 索引类型 | 示例 |
|----------|----------|------|
| 等值查询 | B-Tree | `CREATE INDEX idx_user_email ON users(email)` |
| 范围查询 | B-Tree | `CREATE INDEX idx_order_date ON orders(created_at)` |
| 全文搜索 | GIN | `CREATE INDEX idx_content_search ON posts USING gin(to_tsvector('english', content))` |
| 向量检索 | HNSW | `CREATE INDEX idx_emb ON items USING hnsw(embedding vector_cosine_ops)` |
| 复合条件 | 复合 | `CREATE INDEX idx_order_status_date ON orders(status, created_at)` |

### 分表策略

```sql
-- PostgreSQL 分区 (按时间)
CREATE TABLE orders (
    id BIGSERIAL,
    created_at TIMESTAMP NOT NULL,
    amount DECIMAL(10,2)
) PARTITION BY RANGE (created_at);

CREATE TABLE orders_2024_01 PARTITION OF orders
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');

CREATE TABLE orders_2024_02 PARTITION OF orders
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');

-- MySQL 分库分表 (ShardingSphere)
```

### 查询优化 Checklist

- [ ] 避免 SELECT *
- [ ] 使用覆盖索引
- [ ] 批量插入替代循环
- [ ] 预编译语句
- [ ] 延迟关联优化分页
- [ ] 避免函数索引
- [ ] 分析慢查询日志

## 监控指标

| 指标 | 阈值 | 说明 |
|------|------|------|
| 连接数使用率 | < 70% | 连接池健康 |
| 查询响应时间 P99 | < 500ms | 性能基线 |
| 磁盘使用率 | < 80% | 存储健康 |
| 复制延迟 | < 1s | 主从一致性 |
| 缓存命中率 | > 90% | 缓存效果 |
| 慢查询数量 | < 10/min | 优化需求 |