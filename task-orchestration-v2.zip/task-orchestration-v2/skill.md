---
name: workflowsv2.1
description: 启动多 Agent 任务编排工作流 v2.1，适用于复杂任务分解、功能论证、跨窗口并行与结构化审查
---

# Task Orchestration Skill v2.1

将复杂任务分解为子任务，由多个隔离 Worker 并行执行，最后汇总审查归档。该版本默认使用 manifest、状态同步协议、跨窗口脚本和 specialized agent 协作协议。

## 触发条件

用户输入 `/orchestrate <任务描述>`，或任务满足以下条件：
- 预估步骤 > 5 步
- 涉及多个独立模块
- 需要前后端协作
- 需要并行处理

**跳过编排的情况**（直接执行）：
- 单文件修改
- 简单查询
- 预估步骤 ≤ 3 步

## 执行流程

### Step 1: 复杂度评估

```text
if complexityScore <= triggers.complexityThreshold:
    直接执行，跳过编排
else:
    进入 orchestrator
```

复杂度评分标准：
- 涉及文件数 × 1
- 涉及模块数 × 2
- 需要外部依赖 × 3
- 总分 > 5 触发编排

### Step 2: 启动 Orchestrator

使用 Orchestrator：

```text
readFile("prompts/orchestrator.md")
+ userTask
+ config.json
+ agents.manifest.json
+ docs/state-sync.md
+ docs/cross-window-execution.md
+ docs/specialized-agent-coordination.md
```

Orchestrator 负责：
- 复杂度评估
- 架构论证
- 功能论证派发
- framework / assignments / state 初始化
- specialized agent 路由
- 跨窗口容量调度

### Step 3: 运行时初始化

在目标项目根目录运行：

```powershell
powershell -File scripts/init-workspace-state.ps1 -ProjectRoot "<project-root>" -TaskId "task-2026-001" -TaskName "<task-name>"
```

初始化结果：
- `.claude/workspace/framework.json`
- `.claude/workspace/assignments.json`
- `.claude/workspace/state.json`
- `.claude/workspace/reports/`
- `.claude/workspace/contracts/`
- `.claude/workspace/logs/`
- `.claude/workspace/events/`

### Step 4: Worker 调度与认领

每个 Worker 必须通过脚本认领与释放任务：

```powershell
powershell -File scripts/claim-task.ps1 -TaskId "SUB-001" -WindowId "main" -WorkerId "worker-1"
powershell -File scripts/heartbeat.ps1 -WindowId "main" -TaskIds @("SUB-001")
powershell -File scripts/release-task.ps1 -TaskId "SUB-001" -Status "completed" -WindowId "main"
```

### Step 5: 跨窗口扩容

当 **可用槽位 < 待调度任务数** 且 **当前窗口数 < maxWindows** 时，通过脚本启动新窗口：

```powershell
powershell -File scripts/spawn-window.ps1 -ProjectRoot "<project-root>"
```

新窗口必须注册：

```powershell
powershell -File scripts/register-window.ps1 -WindowId "window-2" -ProjectRoot "<project-root>"
```

### Step 6: 状态汇总与健康检查

- `reconcile-state.ps1`：汇总 assignments / reports / windows 状态
- `window-health-check.ps1`：清理 stale / offline 窗口

```powershell
powershell -File scripts/reconcile-state.ps1 -ProjectRoot "<project-root>"
powershell -File scripts/window-health-check.ps1 -ProjectRoot "<project-root>"
```

### Step 7: 审查验证

审查阶段读取：
- `.claude/workspace/framework.json`
- `.claude/workspace/assignments.json`
- `.claude/workspace/reports/*.json`
- `.claude/memory/decisions/*.md`
- `.claude/workspace/contracts/*.json`
- `schemas/review.schema.json`

重点检查：
- 质量阈值
- 功能链完整性
- 接口映射完整性
- specialized 输出契约完整性

### Step 8: 归档

当 review 通过后：
- 归档到 `.claude/rules/project-spec.md`
- 更新长期项目记忆

## 配置

从 `config.json` 读取：

```json
{
  "triggers": {
    "complexityThreshold": 5
  },
  "limits": {
    "maxDecompositionDepth": 3,
    "maxSubtasks": 8,
    "maxParallelAgents": 8,
    "maxRetries": 1,
    "maxRedoRounds": 1
  },
  "crossWindowExecution": {
    "enabled": true,
    "maxWindows": 4,
    "mainCapacity": 4,
    "subCapacity": 2,
    "heartbeatIntervalMs": 30000,
    "heartbeatTimeoutMs": 90000,
    "spawnMethod": "powershell -File scripts/spawn-window.ps1"
  },
  "stateSync": {
    "strategy": "coordinator-singleton",
    "coordinatorRole": "orchestrator",
    "workerWriteScope": ["reports", "assignments-self-lease"]
  }
}
```

## 输出文件

| 文件 | 路径 | 用途 |
|------|------|------|
| 任务框架 | `.claude/workspace/framework.json` | 静态任务结构 |
| 调度账本 | `.claude/workspace/assignments.json` | 认领 / lease / 窗口分配 |
| 运行状态 | `.claude/workspace/state.json` | 活体状态 |
| 子任务报告 | `.claude/workspace/reports/*.json` | Worker 输出 |
| 对齐检查 | `.claude/workspace/contracts/*.json` | 协作产物 |
| 审查报告 | `.claude/workspace/review.json` | 审查结果 |
| 项目规范 | `.claude/rules/project-spec.md` | 最终归档 |

## 示例

```text
用户: /orchestrate 实现用户认证模块，包含注册、登录、密码重置

Orchestrator:
  复杂度评分: 8 (触发编排)
  触发 frontend-dev 产出功能论证
  触发 backend-dev 产出 API 契约
  生成 alignment.json
  初始化 framework / assignments / state

Worker Pool:
  SUB-001 注册功能
  SUB-002 登录功能
  SUB-003 密码重置
  容量不足时启动 window-2

Reviewer:
  检查质量阈值 + 协作链路 + specialized 输出

Archiver:
  已更新 project-spec.md
```

## 因子记忆命令

本工作流同时支持以下向量记忆相关命令：

### `/debt-check`
扫描因子图谱，列出所有"被替代但未清理"的代码。

```powershell
powershell -File scripts/debt-check.ps1 -ProjectRoot "<project-root>"
```

同时调用 `python vector-memory.py debt` 和 `factors.jsonl` 解析。

### `/factor-search <关键词>`
在向量记忆中检索与关键词相关的历史因子。

```powershell
powershell -File scripts/search-similar.ps1 -Query "<关键词>" -ProjectRoot "<project-root>"
```

返回相似因子列表（按余弦距离排序）。

### `/deprecate <旧模块路径>`
标记旧模块为待清理，设置清理截止日期。

在 `factors.jsonl` 中追加 deprecation notice，或调用：

```powershell
powershell -File scripts/index-factor.ps1 -FactorFile "<项目>/deprecation-record.json"
```
